# Alive - A World Beyond You (Forge 1.20.1)

## Instalación
1. Instala Minecraft Java 1.20.1 con Forge 47.x.
2. Copia el `.jar` en la carpeta `mods` (cliente y servidor).
3. Configuración por mundo: `saves/<mundo>/serverconfig/alive-server.toml`
   (en servidor: `world/serverconfig/alive-server.toml`).

## Qué hace
- **Aldeas**: se registran solas. Si tienen campana y 3+ aldeanos, crecen: llegan colonos, construyen
  viviendas (con camas), granjas (con compostador), almacén (cofres), plaza (campana), caminos y farolas.
  Los edificios usan bloques vanilla y el estilo del bioma. Reparan sus edificios dañados.
- **Aldeanos**: personalidad (Trabajador, Curioso, Sociable, Cauteloso, Independiente, Generoso) y función
  (Agricultor, Constructor, Transportista, Recolector, Guardián, Comerciante, Explorador, Artesano).
  Hacen amistades, pasean, patrullan y se refugian según su personalidad.
- **Construcción progresiva**: los edificios ya no aparecen de golpe. Se genera un plan de obra con `StructureBuilder`
  (el mismo generador de siempre) y los aldeanos constructores (los de función Constructor; si no hay, parados o cualquiera)
  van al almacén, cargan materiales —que se **descuentan de madera/piedra/materiales de la aldea** durante la obra—,
  los llevan al solar y colocan los bloques de abajo hacia arriba (desbroce → cimientos → paredes → tejado → interior).
  Más grande el edificio = más tiempo; más constructores = más rápido (hasta 3). Si faltan materiales la obra se detiene
  y se reanuda sola; si hay monstruos, tormenta o asalto cerca, los constructores abandonan la obra y la retoman al calmarse.
  Solo se trabaja de día y en zonas activas. Se guarda con el mundo (se puede cerrar el juego a medias).
  **Protección**: nunca se pisan cofres ni bloques con datos, bloques de otros mods, ni zonas con construcciones del jugador
  (el solar se rechaza si hay bloques fabricados a menos de 2 bloques); las reparaciones solo rellenan huecos.
- **Caravanas físicas**: el comercio entre aldeas crea una caravana real. La mercancía sale del origen al partir y entra
  en la economía del destino **una sola vez** al llegar (marca `delivered`). Con jugadores cerca se ve un mercader
  ambulante con pan en el inventario (y burro/mula con cofre si la carga es grande) que camina la ruta con el buscador de
  caminos de Minecraft (esquiva agua/lava), descansa a mitad de camino, se detiene si hay monstruos y vuelve a casa.
  Si el mercader muere, se pierde el cargamento. Lejos de los jugadores solo avanza el registro (tiempo de juego), sin
  cargar chunks; al volver se materializan entidades nuevas en la posición correcta (las guardadas en el chunk se descartan).
- **Economía**: comida, madera, piedra y materiales; producción, consumo, escasez, emigración y comercio
  entre aldeas cercanas.
- **Ecosistema**: territorio, manadas de lobos, refugio en tormentas, límite de población y relación
  depredador-presa.
- **Memoria y simulación**: todo se guarda en los datos del mundo. Lejos de los chunks cargados solo se
  calculan números, sin entidades; al volver aparecen los cambios.

## Comandos
- `/alive village` – estado de la aldea más cercana
- `/alive history` – historia reciente de esa aldea
- `/alive ecosystem` – fauna estimada en tu chunk
- `/alive advance <días>` – (op) simula días de golpe, para probar

## Configuración nueva (`alive-server.toml`)
- `progressiveBuilding` (true): construcción progresiva; false = como antes (de golpe, pero con la nueva protección).
- `buildBlocksPerSecond` (2): bloques por segundo y constructor.
- `physicalCaravans` (true): mercaderes reales; false = las caravanas siguen existiendo pero solo como simulación.

## Compilar
`gradle build` (Java 17, Gradle 8.1.1). El jar queda en `build/libs/`.
