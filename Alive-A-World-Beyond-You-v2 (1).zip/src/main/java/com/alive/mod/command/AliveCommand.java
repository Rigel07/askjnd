package com.alive.mod.command;

import com.alive.mod.animal.Species;
import com.alive.mod.config.AliveConfig;
import com.alive.mod.config.Seasons;
import com.alive.mod.data.BuildingType;
import com.alive.mod.data.EcosystemData;
import com.alive.mod.data.Village;
import com.alive.mod.data.VillageData;
import com.alive.mod.economy.EconomySim;
import com.alive.mod.simulation.SimulationScheduler;
import com.alive.mod.trade.CaravanManager;
import com.alive.mod.villager.Role;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.ChunkPos;

import java.util.List;

/** /alive village | history | ecosystem | advance <dias> */
public final class AliveCommand {
    private AliveCommand() {
    }

    public static void register(CommandDispatcher<CommandSourceStack> d) {
        d.register(Commands.literal("alive")
                .then(Commands.literal("village").executes(c -> village(c.getSource())))
                .then(Commands.literal("history").executes(c -> history(c.getSource())))
                .then(Commands.literal("ecosystem").executes(c -> ecosystem(c.getSource())))
                .then(Commands.literal("advance").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("days", IntegerArgumentType.integer(1, 30))
                                .executes(c -> advance(c.getSource(), IntegerArgumentType.getInteger(c, "days"))))));
    }

    private static void say(CommandSourceStack src, String text) {
        src.sendSuccess(() -> Component.literal(text), false);
    }

    private static int village(CommandSourceStack src) {
        ServerLevel level = src.getLevel();
        Village v = VillageData.get(level).findNearest(BlockPos.containing(src.getPosition()), 256);
        if (v == null) {
            src.sendFailure(Component.literal("No hay aldeas registradas a menos de 256 bloques."));
            return 0;
        }
        StringBuilder sb = new StringBuilder();
        sb.append(v.name).append(" - ").append(EconomySim.stageName(v.stage)).append(" (etapa ").append(v.stage).append("/4)\n");
        sb.append("Población: ").append(v.population).append(" (+").append(v.pendingSpawns).append(" en camino), máx. ")
                .append(EconomySim.capacity(v)).append("\n");
        sb.append("Recursos: comida ").append(Math.round(v.food)).append(", madera ").append(Math.round(v.wood))
                .append(", piedra ").append(Math.round(v.stone)).append(", materiales ").append(Math.round(v.materials)).append("\n");
        sb.append("Construcciones del mod: ").append(v.buildings.size()).append(" (");
        for (BuildingType t : BuildingType.values()) {
            sb.append(v.count(t)).append(' ').append(t.label).append(' ');
        }
        sb.append(")\nFunciones: ");
        for (Role r : Role.values()) {
            sb.append(r.label).append(' ').append(v.role(r)).append("  ");
        }
        sb.append("\nRutas comerciales: ").append(v.routes.size()).append(" (caravanas en ruta en la dimensión: ").append(CaravanManager.count(level)).append(")");
        if (v.scarce) sb.append(" | ESCASEZ de alimentos");
        if (!v.hasBell) sb.append(" | sin campana: no crece");
        if (AliveConfig.SEASONS.get()) sb.append(" | ").append(Seasons.at(level.getGameTime()).label);
        say(src, sb.toString());
        return 1;
    }

    private static int history(CommandSourceStack src) {
        Village v = VillageData.get(src.getLevel()).findNearest(BlockPos.containing(src.getPosition()), 256);
        if (v == null) {
            src.sendFailure(Component.literal("No hay aldeas registradas a menos de 256 bloques."));
            return 0;
        }
        StringBuilder sb = new StringBuilder("Historia de " + v.name + ":");
        int from = Math.max(0, v.history.size() - 12);
        for (int i = from; i < v.history.size(); i++) {
            sb.append('\n').append(v.history.get(i));
        }
        say(src, sb.toString());
        return 1;
    }

    private static int ecosystem(CommandSourceStack src) {
        ServerLevel level = src.getLevel();
        EcosystemData data = EcosystemData.get(level);
        BlockPos pos = BlockPos.containing(src.getPosition());
        EcosystemData.Cell cell = data.cell(ChunkPos.asLong(pos), false);
        StringBuilder sb = new StringBuilder("Celdas de ecosistema registradas: " + data.cells().size());
        if (cell == null) {
            sb.append("\nEste chunk aún no tiene registro de fauna.");
        } else {
            sb.append("\nFauna estimada en este chunk:");
            for (Species s : Species.values()) {
                sb.append("\n  ").append(s.name()).append(": ").append(String.format("%.1f", cell.pop[s.ordinal()]));
            }
        }
        say(src, sb.toString());
        return 1;
    }

    private static int advance(CommandSourceStack src, int days) {
        ServerLevel level = src.getLevel();
        long shift = days * 24000L;
        List<Village> list = VillageData.get(level).list();
        for (Village v : list) {
            v.lastSim -= shift;
            v.lastTrade -= shift;
        }
        for (EcosystemData.Cell c : EcosystemData.get(level).cells().values()) {
            c.lastSim -= shift;
        }
        CaravanManager.shift(level, shift);
        SimulationScheduler.forceFull(level);
        say(src, "Simulados " + days + " días de mundo vivo en " + list.size() + " aldea(s).");
        return 1;
    }
}
