package com.alive.mod.animal;

import com.alive.mod.config.AliveConfig;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.animal.Wolf;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraftforge.event.entity.living.BabyEntitySpawnEvent;

import java.util.EnumSet;
import java.util.List;

/** Comportamientos animales extra: territorio, manadas de lobos, refugio en tormentas y limite de poblacion. */
public final class AnimalGoals {
    private AnimalGoals() {
    }

    public static void attach(Mob mob) {
        if (!AliveConfig.ANIMALS.get()) return;
        Species s = Species.of(mob);
        if (s == null || !(mob instanceof PathfinderMob pm)) return;
        if (mob instanceof TamableAnimal t && t.isTame()) return;
        mob.goalSelector.addGoal(6, new TerritoryGoal(pm, s.territory));
        mob.goalSelector.addGoal(3, new StormShelterGoal(pm));
        if (mob instanceof Wolf w) {
            mob.goalSelector.addGoal(5, new PackFollowGoal(w));
        }
    }

    /** Impide nuevas crias si hay demasiados animales de la especie alrededor (poblacion natural limitada). */
    public static void onBreed(BabyEntitySpawnEvent e) {
        if (!AliveConfig.ANIMALS.get()) return;
        Mob parent = e.getParentA();
        if (parent == null || Species.of(parent) == null) return;
        if (parent instanceof TamableAnimal t && t.isTame()) return;
        List<? extends Mob> near = parent.level().getEntitiesOfClass(parent.getClass(), parent.getBoundingBox().inflate(24.0D));
        if (near.size() > AliveConfig.MAX_ANIMALS_NEARBY.get()) {
            e.setCanceled(true);
        }
    }

    /** Los animales permanecen cerca de su zona; el territorio se desplaza muy lentamente con el tiempo. */
    static class TerritoryGoal extends Goal {
        private final PathfinderMob mob;
        private final int radius;
        private BlockPos home;

        TerritoryGoal(PathfinderMob mob, int radius) {
            this.mob = mob;
            this.radius = radius;
            setFlags(EnumSet.of(Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            if (mob.isLeashed() || mob.isPassenger() || mob.isInWater() || mob.getTarget() != null) return false;
            if (home == null || mob.getRandom().nextInt(6000) == 0) {
                home = mob.blockPosition();
                return false;
            }
            if (mob.getRandom().nextInt(80) != 0) return false;
            return mob.blockPosition().distSqr(home) > (double) radius * radius;
        }

        @Override
        public void start() {
            mob.getNavigation().moveTo(home.getX() + 0.5D, home.getY(), home.getZ() + 0.5D, 1.0D);
        }

        @Override
        public boolean canContinueToUse() {
            return !mob.getNavigation().isDone() && mob.getTarget() == null;
        }
    }

    /** Con tormenta, los animales buscan un sitio cubierto (techo, arbol). */
    static class StormShelterGoal extends Goal {
        private final PathfinderMob mob;
        private BlockPos shelter;

        StormShelterGoal(PathfinderMob mob) {
            this.mob = mob;
            setFlags(EnumSet.of(Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            if (!mob.level().isThundering() || mob.isLeashed() || mob.isInWater() || mob.getTarget() != null) return false;
            if (!mob.level().canSeeSky(mob.blockPosition())) return false;
            if (mob.getRandom().nextInt(30) != 0) return false;
            shelter = findShelter();
            return shelter != null;
        }

        private BlockPos findShelter() {
            for (int i = 0; i < 12; i++) {
                BlockPos p = mob.blockPosition().offset(mob.getRandom().nextInt(25) - 12,
                        mob.getRandom().nextInt(7) - 3, mob.getRandom().nextInt(25) - 12);
                BlockPos below = p.below();
                if (!mob.level().canSeeSky(p) && mob.level().getBlockState(p).isAir()
                        && mob.level().getBlockState(below).isFaceSturdy(mob.level(), below, Direction.UP)) {
                    return p;
                }
            }
            return null;
        }

        @Override
        public void start() {
            mob.getNavigation().moveTo(shelter.getX() + 0.5D, shelter.getY(), shelter.getZ() + 0.5D, 1.2D);
        }

        @Override
        public boolean canContinueToUse() {
            return !mob.getNavigation().isDone() && mob.level().isThundering();
        }
    }

    /** Los lobos salvajes se agrupan: siguen al lobo "lider" (menor UUID) de su manada. */
    static class PackFollowGoal extends Goal {
        private final Wolf wolf;
        private Wolf leader;

        PackFollowGoal(Wolf wolf) {
            this.wolf = wolf;
            setFlags(EnumSet.of(Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            if (wolf.isTame() || wolf.getTarget() != null || wolf.isLeashed() || wolf.isInSittingPose()) return false;
            if (wolf.getRandom().nextInt(60) != 0) return false;
            List<Wolf> pack = wolf.level().getEntitiesOfClass(Wolf.class, wolf.getBoundingBox().inflate(24.0D),
                    w -> w != wolf && w.isAlive() && !w.isTame());
            Wolf best = null;
            for (Wolf w : pack) {
                if (best == null || w.getUUID().compareTo(best.getUUID()) < 0) best = w;
            }
            if (best == null || best.getUUID().compareTo(wolf.getUUID()) > 0) return false;
            if (wolf.distanceToSqr(best) <= 49.0D) return false;
            leader = best;
            return true;
        }

        @Override
        public void start() {
            wolf.getNavigation().moveTo(leader, 1.0D);
        }

        @Override
        public boolean canContinueToUse() {
            return leader != null && leader.isAlive() && wolf.getTarget() == null
                    && !wolf.getNavigation().isDone() && wolf.distanceToSqr(leader) > 25.0D;
        }

        @Override
        public void stop() {
            leader = null;
            wolf.getNavigation().stop();
        }
    }
}
