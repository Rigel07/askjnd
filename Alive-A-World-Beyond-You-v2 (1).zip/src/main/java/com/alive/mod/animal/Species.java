package com.alive.mod.animal;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.animal.Animal;

/** Especies que forman parte del ecosistema simulado. El orden debe coincidir con EcosystemData.SPECIES. */
public enum Species {
    COW(EntityType.COW, 6f, false, 48),
    SHEEP(EntityType.SHEEP, 6f, false, 48),
    PIG(EntityType.PIG, 5f, false, 40),
    CHICKEN(EntityType.CHICKEN, 8f, false, 24),
    RABBIT(EntityType.RABBIT, 10f, false, 20),
    FOX(EntityType.FOX, 2f, true, 64),
    WOLF(EntityType.WOLF, 3f, true, 80);

    public final EntityType<? extends Animal> type;
    /** Capacidad de carga por chunk. */
    public final float capacity;
    public final boolean predator;
    /** Radio de territorio en bloques. */
    public final int territory;

    Species(EntityType<? extends Animal> type, float capacity, boolean predator, int territory) {
        this.type = type;
        this.capacity = capacity;
        this.predator = predator;
        this.territory = territory;
    }

    public static Species of(Entity e) {
        for (Species s : values()) {
            if (e.getType() == s.type) return s;
        }
        return null;
    }
}
