package com.alive.mod.animal;

import com.alive.mod.config.AliveConfig;
import com.alive.mod.config.Seasons;
import com.alive.mod.data.EcosystemData;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Ecosistema en dos niveles:
 *  - Cerca de jugadores: se censan los animales reales por chunk.
 *  - Chunks descargados: la poblacion evoluciona con ecuaciones (crecimiento logistico + depredacion).
 * Al cargar un chunk se reconcilia: si la simulacion dice que hay mas animales que los reales, aparecen.
 */
public final class EcosystemManager {
    private static final long STEP = 6000L;
    private static final int RADIUS_CHUNKS = 4;
    private static final Map<ResourceKey<Level>, Map<Long, Long>> PENDING = new ConcurrentHashMap<>();

    private static final int RABBIT = Species.RABBIT.ordinal();
    private static final int CHICKEN = Species.CHICKEN.ordinal();
    private static final int SHEEP = Species.SHEEP.ordinal();
    private static final int FOX = Species.FOX.ordinal();
    private static final int WOLF = Species.WOLF.ordinal();

    private EcosystemManager() {
    }

    public static void clear() {
        PENDING.clear();
    }

    /** Llamado al cargar un chunk: se reconciliara unos segundos despues, cuando ya tenga entidades. */
    public static void onChunkLoad(ServerLevel level, long chunkKey) {
        Map<Long, Long> m = PENDING.computeIfAbsent(level.dimension(), k -> new ConcurrentHashMap<>());
        if (m.size() < 4000) m.put(chunkKey, level.getGameTime());
    }

    // ------------------------------------------------------------------ pasada principal

    public static void process(ServerLevel level) {
        if (!AliveConfig.ANIMALS.get()) return;
        EcosystemData data = EcosystemData.get(level);
        long now = level.getGameTime();
        census(level, data, now);
        if (AliveConfig.OFFLINE_SIM.get()) simulateOffline(level, data, now);
        data.setDirty();
    }

    private static boolean countable(Animal a) {
        if (Species.of(a) == null) return false;
        if (a instanceof TamableAnimal t && t.isTame()) return false;
        return !a.hasCustomName() && !a.isLeashed();
    }

    /** Cuenta los animales reales cerca de cada jugador y guarda el resultado por chunk. */
    private static void census(ServerLevel level, EcosystemData data, long now) {
        for (ServerPlayer p : level.players()) {
            ChunkPos pc = p.chunkPosition();
            AABB box = new AABB((pc.x - RADIUS_CHUNKS) * 16.0, level.getMinBuildHeight(), (pc.z - RADIUS_CHUNKS) * 16.0,
                    (pc.x + RADIUS_CHUNKS + 1) * 16.0, level.getMaxBuildHeight(), (pc.z + RADIUS_CHUNKS + 1) * 16.0);
            List<Animal> animals = level.getEntitiesOfClass(Animal.class, box, EcosystemManager::countable);
            Map<Long, float[]> counts = new HashMap<>();
            for (Animal a : animals) {
                Species s = Species.of(a);
                long k = ChunkPos.asLong(a.blockPosition());
                counts.computeIfAbsent(k, x -> new float[EcosystemData.SPECIES])[s.ordinal()]++;
            }
            for (int dx = -RADIUS_CHUNKS; dx <= RADIUS_CHUNKS; dx++) {
                for (int dz = -RADIUS_CHUNKS; dz <= RADIUS_CHUNKS; dz++) {
                    int cx = pc.x + dx;
                    int cz = pc.z + dz;
                    if (!level.getChunkSource().hasChunk(cx, cz)) continue;
                    long k = ChunkPos.asLong(cx, cz);
                    float[] c = counts.get(k);
                    if (c != null) {
                        EcosystemData.Cell cell = data.cell(k, true);
                        System.arraycopy(c, 0, cell.pop, 0, c.length);
                        cell.lastSim = now;
                    } else {
                        EcosystemData.Cell cell = data.cell(k, false);
                        if (cell != null) {
                            java.util.Arrays.fill(cell.pop, 0f);
                            cell.lastSim = now;
                        }
                    }
                }
            }
        }
    }

    /** Evoluciona matematicamente las celdas cuyos chunks no estan cargados. */
    private static void simulateOffline(ServerLevel level, EcosystemData data, long now) {
        RandomSource rnd = level.getRandom();
        java.util.ArrayList<Long> dead = new java.util.ArrayList<>();
        for (Map.Entry<Long, EcosystemData.Cell> e : data.cells().entrySet()) {
            EcosystemData.Cell c = e.getValue();
            long elapsed = now - c.lastSim;
            if (elapsed < STEP) continue;
            long k = e.getKey();
            int cx = (int) (k & 0xFFFFFFFFL);
            int cz = (int) (k >>> 32);
            if (level.getChunkSource().hasChunk(cx, cz)) continue;
            long total = elapsed / STEP;
            int steps = (int) Math.min(60, total);
            for (int i = 0; i < steps; i++) {
                stepCell(c.pop, Seasons.animal(c.lastSim + (i + 1L) * STEP));
            }
            c.lastSim = total > 60 ? now : c.lastSim + steps * STEP;
            if (c.total() < 0.05f) dead.add(k);
        }
        for (Long k : dead) {
            data.cells().remove(k);
        }
    }

    /** Un paso (cuarto de dia): crecimiento logistico de presas y relacion depredador-presa. */
    static void stepCell(float[] p, double season) {
        for (Species s : Species.values()) {
            int i = s.ordinal();
            if (!s.predator && p[i] > 0f) {
                p[i] += (float) (0.07 * season * p[i] * (1.0 - p[i] / s.capacity));
            }
        }
        float fox = p[FOX];
        float wolf = p[WOLF];
        float r1 = Math.min(p[RABBIT] * 0.5f, fox * 0.4f);
        p[RABBIT] -= r1;
        float c1 = Math.min(p[CHICKEN] * 0.3f, fox * 0.2f);
        p[CHICKEN] -= c1;
        float s1 = Math.min(p[SHEEP] * 0.3f, wolf * 0.25f);
        p[SHEEP] -= s1;
        float r2 = Math.min(p[RABBIT] * 0.4f, wolf * 0.2f);
        p[RABBIT] -= r2;
        p[FOX] = predator(fox, r1 + c1, Species.FOX.capacity);
        p[WOLF] = predator(wolf, s1 + r2, Species.WOLF.capacity);
    }

    private static float predator(float pop, float eaten, float cap) {
        if (pop <= 0f) return 0f;
        float need = pop * 0.4f;
        float next = eaten >= need * 0.8f ? pop + 0.05f * pop * (1f - pop / cap) : pop * 0.92f;
        return next < 0.15f ? 0f : next;
    }

    // ------------------------------------------------------------------ reconciliacion al cargar chunks

    public static void reconcile(ServerLevel level) {
        if (!AliveConfig.ANIMALS.get()) return;
        Map<Long, Long> m = PENDING.get(level.dimension());
        if (m == null || m.isEmpty()) return;
        EcosystemData data = EcosystemData.get(level);
        long now = level.getGameTime();
        RandomSource rnd = level.getRandom();
        int done = 0;
        Iterator<Map.Entry<Long, Long>> it = m.entrySet().iterator();
        while (it.hasNext() && done < 12) {
            Map.Entry<Long, Long> e = it.next();
            if (now - e.getValue() < 60L) continue;
            it.remove();
            done++;
            long k = e.getKey();
            EcosystemData.Cell cell = data.cell(k, false);
            if (cell == null) continue;
            int cx = (int) (k & 0xFFFFFFFFL);
            int cz = (int) (k >>> 32);
            if (!level.getChunkSource().hasChunk(cx, cz)) continue;
            reconcileChunk(level, cell, cx, cz, rnd);
        }
        data.setDirty();
    }

    private static void reconcileChunk(ServerLevel level, EcosystemData.Cell cell, int cx, int cz, RandomSource rnd) {
        AABB box = new AABB(cx * 16.0, level.getMinBuildHeight(), cz * 16.0,
                cx * 16.0 + 16.0, level.getMaxBuildHeight(), cz * 16.0 + 16.0);
        int[] real = new int[EcosystemData.SPECIES];
        for (Animal a : level.getEntitiesOfClass(Animal.class, box, EcosystemManager::countable)) {
            real[Species.of(a).ordinal()]++;
        }
        for (Species s : Species.values()) {
            int i = s.ordinal();
            int expected = Math.round(cell.pop[i]);
            int cap = (int) Math.ceil(s.capacity);
            if (AliveConfig.OFFLINE_SIM.get() && expected > real[i] && real[i] < cap) {
                int want = Math.min(2, expected - real[i]);
                int spawned = 0;
                for (int j = 0; j < want; j++) {
                    if (spawn(level, s, cx, cz, rnd)) spawned++;
                }
                cell.pop[i] = real[i] + spawned;
            } else {
                cell.pop[i] = real[i];
            }
        }
    }

    private static boolean spawn(ServerLevel level, Species s, int cx, int cz, RandomSource rnd) {
        int x = (cx << 4) + rnd.nextInt(16);
        int z = (cz << 4) + rnd.nextInt(16);
        int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
        BlockPos pos = new BlockPos(x, y, z);
        BlockPos below = pos.below();
        BlockState bs = level.getBlockState(below);
        if (!bs.getFluidState().isEmpty() || !bs.isFaceSturdy(level, below, Direction.UP)) return false;
        if (!level.getBlockState(pos).getCollisionShape(level, pos).isEmpty()) return false;
        if (level.getNearestPlayer(x + 0.5D, y, z + 0.5D, 16.0D, false) != null) return false;
        return s.type.spawn(level, pos, MobSpawnType.NATURAL) != null;
    }
}
