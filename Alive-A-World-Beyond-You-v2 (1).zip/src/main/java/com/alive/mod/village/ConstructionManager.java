package com.alive.mod.village;

import com.alive.mod.config.AliveConfig;
import com.alive.mod.data.BuildPlan;
import com.alive.mod.data.Building;
import com.alive.mod.data.BuildingType;
import com.alive.mod.data.Village;
import com.alive.mod.data.VillageData;
import com.alive.mod.economy.EconomySim;
import com.alive.mod.villager.Role;
import com.alive.mod.villager.VillagerLife;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.memory.MemoryModuleType;
import net.minecraft.world.entity.ai.memory.WalkTarget;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.npc.VillagerProfession;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Obra progresiva: los aldeanos constructores van al almacen, cargan materiales (que se descuentan de la aldea),
 * los llevan al solar y colocan los bloques del plan poco a poco. Se ejecuta una vez por segundo y SOLO en zonas activas.
 * El plan lo genera StructureBuilder; la economia es la de EconomySim.
 */
public final class ConstructionManager {
    public static final String TAG_CARRY = "alive_carry";
    /** Bloques de material que carga un constructor por viaje. */
    private static final int BATCH = 8;
    private static final int MAX_TRIP_SECONDS = 45;
    private static final int CALM_SECONDS = 6;

    private static final Map<UUID, Crew> CREWS = new HashMap<>();

    private static final class Worker {
        int load;
        int trip;
    }

    private static final class Crew {
        final Map<UUID, Worker> workers = new HashMap<>();
        int calm = CALM_SECONDS;
        boolean threatened;
        boolean night;
    }

    private ConstructionManager() {
    }

    public static void clear() {
        CREWS.clear();
    }

    /** Un aldeano que entra al mundo con material en la mano (por cierre del juego a medio viaje) lo suelta. */
    public static void dropCarry(Villager vl) {
        if (vl.getPersistentData().getBoolean(TAG_CARRY)) {
            vl.setItemSlot(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
            vl.getPersistentData().remove(TAG_CARRY);
        }
    }

    public static void tick(ServerLevel level) {
        if (!AliveConfig.VILLAGE_GROWTH.get()) return;
        VillageData data = VillageData.get(level);
        for (Village v : data.list()) {
            Building b = v.underConstruction();
            if (b == null) {
                Crew old = CREWS.remove(v.id);
                if (old != null) release(level, old);
                continue;
            }
            BlockPos site = b.pos.offset(2, 1, 2);
            if (!level.isPositionEntityTicking(site)) continue;
            try {
                work(level, data, v, b, site);
            } catch (RuntimeException ex) {
                // Una obra defectuosa no debe tumbar el servidor: se deja el plan como esta y se reintenta mas tarde
                com.alive.mod.AliveMod.LOGGER.warn("Alive: error en obra de {}: {}", v.name, ex.toString());
            }
        }
    }

    private static void work(ServerLevel level, VillageData data, Village v, Building b, BlockPos site) {
        BuildPlan plan = b.plan;
        Crew crew = CREWS.computeIfAbsent(v.id, k -> new Crew());

        // ---- amenazas: los constructores abandonan la obra y se refugian
        AABB danger = new AABB(site).inflate(24, 10, 24);
        boolean threat = level.isThundering() || level.isRaided(site)
                || !level.getEntitiesOfClass(Monster.class, danger, Monster::isAlive).isEmpty();
        if (threat) {
            crew.calm = 0;
            if (!crew.threatened) {
                crew.threatened = true;
                v.log(level.getGameTime(), "Amenaza cerca de la obra: los constructores dejan su trabajo y se ponen a salvo.");
                data.setDirty();
            }
            for (Map.Entry<UUID, Worker> e : crew.workers.entrySet()) {
                Villager vl = villager(level, e.getKey());
                if (vl == null) continue;
                e.getValue().load = 0;
                hand(vl, ItemStack.EMPTY);
                walk(vl, Vec3.atCenterOf(v.center), 0.7F, 2);
            }
            return;
        }
        if (crew.calm < CALM_SECONDS) {
            crew.calm++;
            return;
        }
        if (crew.threatened) {
            crew.threatened = false;
            v.log(level.getGameTime(), "Pasó el peligro: los constructores retoman la obra.");
            data.setDirty();
        }

        // ---- los constructores trabajan de dia
        long dt = level.getDayTime() % 24000L;
        if (dt >= 12000L) {
            if (!crew.night) {
                crew.night = true;
                release(level, crew);
            }
            return;
        }
        crew.night = false;

        // ---- cuadrilla
        int wanted = Math.max(1, Math.min(3, 1 + plan.solid / 90));
        refreshCrew(level, crew, site, wanted);
        if (crew.workers.isEmpty()) return;

        int rate = AliveConfig.BUILD_BLOCKS_PER_SECOND.get();
        BlockPos supply = supplyPoint(v);
        double per = 1.0 / Math.max(1, plan.solid);
        double cw = EconomySim.COST_WOOD * per;
        double cs = EconomySim.COST_STONE * per;
        double cm = EconomySim.COST_MATERIALS * per;
        BlockPos approach = b.pos.offset(2, 1, -2);

        for (Map.Entry<UUID, Worker> e : crew.workers.entrySet()) {
            Villager vl = villager(level, e.getKey());
            if (vl == null) continue;
            Worker w = e.getValue();
            if (plan.done >= plan.size()) break;

            if (w.load <= 0) {
                // 1) ir al almacen a por materiales
                if (vl.blockPosition().distSqr(supply) > 16.0D) {
                    travel(level, vl, w, supply, 0.55F);
                    continue;
                }
                int remaining = remainingSolid(plan);
                int batch = Math.min(BATCH, Math.max(1, remaining));
                if (v.wood >= cw * batch && v.stone >= cs * batch && v.materials >= cm * batch) {
                    v.wood -= cw * batch;
                    v.stone -= cs * batch;
                    v.materials -= cm * batch;
                    w.load = batch;
                    w.trip = 0;
                    hand(vl, new ItemStack(materialItem(plan)));
                    if (plan.stalled) {
                        plan.stalled = false;
                        v.log(level.getGameTime(), "Llegan materiales: se reanuda la obra.");
                    }
                    data.setDirty();
                } else {
                    // Faltan materiales: la obra se detiene temporalmente
                    hand(vl, ItemStack.EMPTY);
                    if (!plan.stalled) {
                        plan.stalled = true;
                        v.log(level.getGameTime(), "Obra detenida: faltan materiales en la aldea.");
                        data.setDirty();
                    }
                }
            } else {
                // 2) llevar la carga al solar y colocar bloques
                if (vl.blockPosition().distSqr(approach) > 36.0D && vl.blockPosition().distSqr(site) > 36.0D) {
                    travel(level, vl, w, approach, 0.55F);
                    continue;
                }
                w.trip = 0;
                int placedNow = 0;
                while (placedNow < rate && plan.done < plan.size()) {
                    int i = plan.done;
                    boolean solid = !plan.states.get(i).isAir();
                    if (solid && w.load <= 0) break;
                    boolean linked = StructureBuilder.linkedWithNext(plan.states.get(i)) && i + 1 < plan.size();
                    StructureBuilder.applyStep(level, plan, i);
                    plan.done++;
                    placedNow++;
                    if (solid) w.load--;
                    if (linked) {
                        int j = plan.done;
                        boolean solid2 = !plan.states.get(j).isAir();
                        StructureBuilder.applyStep(level, plan, j);
                        plan.done++;
                        if (solid2) w.load--;
                    }
                }
                if (placedNow > 0) {
                    BlockPos target = plan.pos.get(Math.min(plan.done, plan.size() - 1));
                    vl.getLookControl().setLookAt(target.getX() + 0.5, target.getY() + 0.5, target.getZ() + 0.5);
                    vl.swing(InteractionHand.MAIN_HAND);
                    data.setDirty();
                }
                if (w.load <= 0) hand(vl, ItemStack.EMPTY);
            }
        }

        if (plan.done >= plan.size()) {
            finish(level, data, v, b);
        }
    }

    private static void finish(ServerLevel level, VillageData data, Village v, Building b) {
        StructureBuilder.complete(level, b, v);
        v.log(level.getGameTime(), "Los aldeanos terminan de construir una " + b.type.label + ".");
        Crew crew = CREWS.remove(v.id);
        if (crew != null) release(level, crew);
        data.setDirty();
    }

    // ------------------------------------------------------------------ cuadrilla y movimiento

    private static void refreshCrew(ServerLevel level, Crew crew, BlockPos site, int wanted) {
        Iterator<Map.Entry<UUID, Worker>> it = crew.workers.entrySet().iterator();
        while (it.hasNext()) {
            Villager vl = villager(level, it.next().getKey());
            if (vl == null || !vl.isAlive()) it.remove();
        }
        if (crew.workers.size() >= wanted) return;
        List<Villager> cands = new ArrayList<>(level.getEntitiesOfClass(Villager.class,
                new AABB(site).inflate(64, 24, 64), x -> x.isAlive() && !x.isBaby() && !x.isSleeping()));
        cands.removeIf(x -> crew.workers.containsKey(x.getUUID()));
        cands.sort(Comparator.<Villager>comparingInt(x -> {
            if (VillagerLife.refreshRole(x) == Role.BUILDER) return 0;
            return x.getVillagerData().getProfession() == VillagerProfession.NONE ? 1 : 2;
        }).thenComparingDouble(x -> x.distanceToSqr(site.getX(), site.getY(), site.getZ())));
        for (Villager x : cands) {
            if (crew.workers.size() >= wanted) break;
            crew.workers.put(x.getUUID(), new Worker());
        }
    }

    private static void release(ServerLevel level, Crew crew) {
        for (UUID id : crew.workers.keySet()) {
            Villager vl = villager(level, id);
            if (vl != null) hand(vl, ItemStack.EMPTY);
        }
        crew.workers.clear();
    }

    private static Villager villager(ServerLevel level, UUID id) {
        Entity e = level.getEntity(id);
        return e instanceof Villager v && v.isAlive() ? v : null;
    }

    private static void hand(Villager vl, ItemStack stack) {
        vl.setItemSlot(EquipmentSlot.MAINHAND, stack);
        vl.setDropChance(EquipmentSlot.MAINHAND, 0.0F);
        if (stack.isEmpty()) {
            vl.getPersistentData().remove(TAG_CARRY);
        } else {
            vl.getPersistentData().putBoolean(TAG_CARRY, true);
        }
    }

    private static void walk(Villager vl, Vec3 to, float speed, int close) {
        vl.getBrain().setMemory(MemoryModuleType.WALK_TARGET, new WalkTarget(to, speed, close));
    }

    /** Camina hacia un punto; si tarda demasiado (obstaculo) se le coloca cerca para no bloquear la obra. */
    private static void travel(ServerLevel level, Villager vl, Worker w, BlockPos dest, float speed) {
        walk(vl, Vec3.atBottomCenterOf(dest), speed, 2);
        if (++w.trip > MAX_TRIP_SECONDS) {
            w.trip = 0;
            int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, dest.getX(), dest.getZ());
            vl.teleportTo(dest.getX() + 0.5, y, dest.getZ() + 0.5);
        }
    }

    /** Punto de abastecimiento: el almacen terminado mas cercano al centro, o el centro de la aldea. */
    private static BlockPos supplyPoint(Village v) {
        BlockPos best = v.center;
        double bd = Double.MAX_VALUE;
        for (Building b : v.buildings) {
            if (b.type == BuildingType.STORAGE && b.isComplete()) {
                double d = b.pos.distSqr(v.center);
                if (d < bd) {
                    bd = d;
                    best = b.pos.offset(2, 1, 2);
                }
            }
        }
        return best;
    }

    private static int remainingSolid(BuildPlan plan) {
        int n = 0;
        for (int i = plan.done; i < plan.size(); i++) {
            if (!plan.states.get(i).isAir()) n++;
        }
        return n;
    }

    /** Item que lleva el constructor en la mano, segun el siguiente bloque a colocar. */
    private static net.minecraft.world.item.Item materialItem(BuildPlan plan) {
        for (int i = plan.done; i < plan.size(); i++) {
            if (!plan.states.get(i).isAir()) {
                net.minecraft.world.item.Item it = plan.states.get(i).getBlock().asItem();
                if (it != Items.AIR) return it;
            }
        }
        return Items.OAK_PLANKS;
    }
}
