package com.alive.mod.village;

import com.alive.mod.config.AliveConfig;
import com.alive.mod.data.BuildPlan;
import com.alive.mod.data.Building;
import com.alive.mod.data.BuildingType;
import com.alive.mod.data.Village;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Holder;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.Biomes;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.FarmBlock;
import net.minecraft.world.level.block.FenceBlock;
import net.minecraft.world.level.block.FenceGateBlock;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BedPart;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.levelgen.Heightmap;

import java.util.ArrayList;
import java.util.List;

/**
 * Construccion de estructuras con bloques vanilla (terreno de 5x5), eleccion de solar,
 * caminos, farolas y deteccion de daños para reparar.
 */
public final class StructureBuilder {
    public record Style(Block planks, Block log, Block base, Block door, Block fence, Block gate) {
    }

    private static final Style[] STYLES = {
            new Style(Blocks.OAK_PLANKS, Blocks.OAK_LOG, Blocks.COBBLESTONE, Blocks.OAK_DOOR, Blocks.OAK_FENCE, Blocks.OAK_FENCE_GATE),
            new Style(Blocks.SPRUCE_PLANKS, Blocks.SPRUCE_LOG, Blocks.COBBLESTONE, Blocks.SPRUCE_DOOR, Blocks.SPRUCE_FENCE, Blocks.SPRUCE_FENCE_GATE),
            new Style(Blocks.ACACIA_PLANKS, Blocks.ACACIA_LOG, Blocks.COBBLESTONE, Blocks.ACACIA_DOOR, Blocks.ACACIA_FENCE, Blocks.ACACIA_FENCE_GATE),
            new Style(Blocks.JUNGLE_PLANKS, Blocks.JUNGLE_LOG, Blocks.COBBLESTONE, Blocks.JUNGLE_DOOR, Blocks.JUNGLE_FENCE, Blocks.JUNGLE_FENCE_GATE),
            new Style(Blocks.SANDSTONE, Blocks.CUT_SANDSTONE, Blocks.SANDSTONE, Blocks.ACACIA_DOOR, Blocks.ACACIA_FENCE, Blocks.ACACIA_FENCE_GATE)
    };

    private static final Heightmap.Types SURFACE = Heightmap.Types.MOTION_BLOCKING_NO_LEAVES;

    private StructureBuilder() {
    }

    // ------------------------------------------------------------------ eleccion

    public static BuildingType chooseType(Village v) {
        int houses = v.count(BuildingType.HOUSE);
        int farms = v.count(BuildingType.FARM);
        int demand = v.population + v.pendingSpawns;
        if (Math.max(6, v.baseCapacity) + houses * 2 < demand + 2) return BuildingType.HOUSE;
        if (farms < 1 + demand / 8) return BuildingType.FARM;
        if (v.stage >= 2 && v.count(BuildingType.STORAGE) == 0) return BuildingType.STORAGE;
        if (v.stage >= 3 && v.count(BuildingType.PLAZA) == 0) return BuildingType.PLAZA;
        return (v.stage >= 2 && v.buildings.size() % 3 == 0) ? BuildingType.FARM : BuildingType.HOUSE;
    }

    /** Estilo segun el bioma, para respetar el aspecto de la zona. */
    public static int pickStyle(ServerLevel level, BlockPos pos) {
        Holder<Biome> b = level.getBiome(pos);
        if (isAny(b, Biomes.DESERT, Biomes.BADLANDS, Biomes.ERODED_BADLANDS, Biomes.WOODED_BADLANDS)) return 4;
        if (isAny(b, Biomes.TAIGA, Biomes.SNOWY_TAIGA, Biomes.OLD_GROWTH_PINE_TAIGA,
                Biomes.OLD_GROWTH_SPRUCE_TAIGA, Biomes.SNOWY_PLAINS)) return 1;
        if (isAny(b, Biomes.SAVANNA, Biomes.SAVANNA_PLATEAU, Biomes.WINDSWEPT_SAVANNA)) return 2;
        if (isAny(b, Biomes.JUNGLE, Biomes.SPARSE_JUNGLE, Biomes.BAMBOO_JUNGLE)) return 3;
        return 0;
    }

    @SafeVarargs
    private static boolean isAny(Holder<Biome> holder, ResourceKey<Biome>... keys) {
        for (ResourceKey<Biome> k : keys) {
            if (holder.is(k)) return true;
        }
        return false;
    }

    /** Busca un solar plano, libre y sin solapar otras construcciones. Devuelve null si no hay. */
    private static BlockPos findSite(ServerLevel level, Village v, RandomSource rnd) {
        int maxDist = Math.max(12, Math.min(AliveConfig.MAX_EXPANSION.get(), 20 + v.stage * 14));
        int[] gx = {0, 4, 0, 4, 2};
        int[] gz = {0, 0, 4, 4, 2};
        for (int attempt = 0; attempt < 30; attempt++) {
            double ang = rnd.nextDouble() * Math.PI * 2.0;
            double dist = 9 + rnd.nextDouble() * (maxDist - 9);
            int x = v.center.getX() + (int) Math.round(Math.cos(ang) * dist) - 2;
            int z = v.center.getZ() + (int) Math.round(Math.sin(ang) * dist) - 2;
            if (!level.isLoaded(new BlockPos(x, 64, z)) || !level.isLoaded(new BlockPos(x + 4, 64, z))
                    || !level.isLoaded(new BlockPos(x, 64, z + 4)) || !level.isLoaded(new BlockPos(x + 4, 64, z + 4))) {
                continue;
            }
            int min = Integer.MAX_VALUE;
            int max = Integer.MIN_VALUE;
            boolean ok = true;
            for (int i = 0; i < gx.length && ok; i++) {
                int gy = level.getHeight(SURFACE, x + gx[i], z + gz[i]) - 1;
                BlockState st = level.getBlockState(new BlockPos(x + gx[i], gy, z + gz[i]));
                if (st.isAir() || !st.getFluidState().isEmpty() || st.is(BlockTags.LEAVES)) {
                    ok = false;
                } else {
                    min = Math.min(min, gy);
                    max = Math.max(max, gy);
                }
            }
            if (!ok || max - min > 1) continue;
            int y0 = max;
            if (y0 + 6 >= level.getMaxBuildHeight() || y0 - 4 <= level.getMinBuildHeight()) continue;
            for (int dx = 0; dx < 5 && ok; dx++) {
                for (int dz = 0; dz < 5 && ok; dz++) {
                    for (int h = 1; h <= 5; h++) {
                        BlockState st = level.getBlockState(new BlockPos(x + dx, y0 + h, z + dz));
                        if (!(st.isAir() || st.canBeReplaced() || st.is(BlockTags.LEAVES))) {
                            ok = false;
                            break;
                        }
                    }
                }
            }
            if (!ok) continue;
            // Proteccion: el suelo debe ser sustituible y no puede haber construcciones del jugador ni cofres cerca
            for (int dx = 0; dx < 5 && ok; dx++) {
                for (int dz = 0; dz < 5 && ok; dz++) {
                    if (!Protection.canOverwrite(level, new BlockPos(x + dx, y0, z + dz))) ok = false;
                }
            }
            if (!ok || Protection.hasPlayerStructure(level, x - 2, z - 2, 9, 9, y0 - 4, y0 + 6)) continue;
            for (Building b : v.buildings) {
                if (Math.max(Math.abs(b.pos.getX() - x), Math.abs(b.pos.getZ() - z)) < 8) {
                    ok = false;
                    break;
                }
            }
            if (ok) return new BlockPos(x, y0, z);
        }
        return null;
    }

    /**
     * Intenta iniciar un edificio nuevo. Con construccion progresiva solo se crea el PLAN de obra (los constructores
     * lo ejecutan despues, ver ConstructionManager); sin ella se construye de golpe como antes.
     */
    public static boolean place(ServerLevel level, Village v, BuildingType type, RandomSource rnd) {
        BlockPos site = findSite(level, v, rnd);
        if (site == null) return false;
        Building b = new Building(type, site, pickStyle(level, site));
        if (AliveConfig.PROGRESSIVE_BUILD.get()) {
            b.plan = plan(level, b, v);
            if (b.plan.size() == 0) b.plan = null;
        } else {
            buildNew(level, b, v);
        }
        v.buildings.add(b);
        if (b.plan == null) complete(level, b, v);
        return true;
    }

    /** Remate de un edificio terminado: contenido de cofres, camino hasta el centro y farola. */
    public static void complete(ServerLevel level, Building b, Village v) {
        b.plan = null;
        fillStorage(level, b, v);
        pathToCenter(level, b.pos.getX() + 2, b.pos.getZ() - 1, v.center);
        lampPost(level, STYLES[Math.floorMod(b.style, STYLES.length)], b.pos.getX() + 5, b.pos.getZ() - 1);
    }

    /** Aplica un paso del plan respetando la proteccion. Devuelve true si realmente se coloco un bloque. */
    public static boolean applyStep(ServerLevel level, BuildPlan plan, int i) {
        BlockPos p = plan.pos.get(i);
        BlockState st = plan.states.get(i);
        if (!level.isLoaded(p)) return false;
        BlockState cur = level.getBlockState(p);
        if (cur == st || !Protection.canOverwrite(level, p)) return false;
        level.setBlock(p, st, 3);
        if (!st.isAir()) {
            level.playSound(null, p, st.getSoundType().getPlaceSound(), net.minecraft.sounds.SoundSource.BLOCKS, 0.6F, 0.9F);
        }
        return true;
    }

    /** Un paso que debe ir seguido de su pareja en el mismo lote (cama, puerta) para no dejar piezas a medias. */
    public static boolean linkedWithNext(BlockState st) {
        if (st.getBlock() instanceof BedBlock) return st.getValue(BedBlock.PART) == BedPart.FOOT;
        if (st.getBlock() instanceof DoorBlock) return st.getValue(DoorBlock.HALF) == DoubleBlockHalf.LOWER;
        return false;
    }

    // ------------------------------------------------------------------ construccion

    /** Captura de bloques para generar un plan en lugar de colocarlos. null = colocacion directa. */
    private static List<Object[]> capture;
    /** En colocacion directa: true = reparacion (solo rellena huecos), false = obra nueva. */
    private static boolean repairMode;

    /** Reparacion de un edificio dañado: solo rellena huecos, no pisa nada que ya exista. */
    public static void build(ServerLevel level, Building b, Village v) {
        repairMode = true;
        try {
            generate(level, b, v);
        } finally {
            repairMode = false;
        }
        fillStorage(level, b, v);
    }

    private static void buildNew(ServerLevel level, Building b, Village v) {
        repairMode = false;
        generate(level, b, v);
        fillStorage(level, b, v);
    }

    /** Genera el plan de obra del edificio: primero el desbroce, luego los bloques de abajo hacia arriba. */
    private static BuildPlan plan(ServerLevel level, Building b, Village v) {
        List<Object[]> list = new ArrayList<>();
        capture = list;
        try {
            generate(level, b, v);
        } finally {
            capture = null;
        }
        // Si varias piezas caen en la misma posicion (pared + puerta, pared + ventana) solo cuenta la ultima
        java.util.Map<Long, Integer> last = new java.util.HashMap<>();
        for (int i = 0; i < list.size(); i++) {
            last.put(((BlockPos) list.get(i)[0]).asLong(), i);
        }
        List<Object[]> unique = new ArrayList<>();
        for (int i = 0; i < list.size(); i++) {
            if (last.get(((BlockPos) list.get(i)[0]).asLong()) == i) unique.add(list.get(i));
        }
        list = unique;
        int y0 = b.pos.getY();
        // Clave de orden: desbroce primero; despues por altura (la mitad superior de una puerta cuenta como la inferior)
        list.sort((a, c) -> Integer.compare(sortKey(a, y0), sortKey(c, y0)));
        BuildPlan plan = new BuildPlan();
        for (Object[] e : list) {
            plan.add((BlockPos) e[0], (BlockState) e[1]);
        }
        return plan;
    }

    private static int sortKey(Object[] e, int y0) {
        BlockPos p = (BlockPos) e[0];
        BlockState st = (BlockState) e[1];
        if (st.isAir()) return -1000;
        int y = p.getY();
        if (st.getBlock() instanceof DoorBlock && st.getValue(DoorBlock.HALF) == DoubleBlockHalf.UPPER) y--;
        return y;
    }

    private static void generate(ServerLevel level, Building b, Village v) {
        Style s = STYLES[Math.floorMod(b.style, STYLES.length)];
        int x0 = b.pos.getX();
        int y0 = b.pos.getY();
        int z0 = b.pos.getZ();
        if (capture != null || !repairMode) clear(level, x0, y0 + 1, z0, 5, 5, 5);
        switch (b.type) {
            case HOUSE -> house(level, s, x0, y0, z0, false, v);
            case STORAGE -> house(level, s, x0, y0, z0, true, v);
            case FARM -> farm(level, s, x0, y0, z0, new java.util.Random(b.pos.asLong()));
            case PLAZA -> plaza(level, s, x0, y0, z0);
        }
    }

    /** Contenido inicial de los cofres del almacen (solo si estan vacios). */
    private static void fillStorage(ServerLevel l, Building b, Village v) {
        if (b.type != BuildingType.STORAGE) return;
        Style s = STYLES[Math.floorMod(b.style, STYLES.length)];
        BlockPos c1 = b.pos.offset(1, 1, 3);
        BlockPos c2 = b.pos.offset(3, 1, 3);
        if (l.getBlockEntity(c1) instanceof ChestBlockEntity chest && chest.isEmpty()) {
            chest.setItem(0, new ItemStack(Items.BREAD, Math.max(1, Math.min(64, (int) (v.food / 8)))));
        }
        if (l.getBlockEntity(c2) instanceof ChestBlockEntity chest && chest.isEmpty()) {
            chest.setItem(0, new ItemStack(s.log().asItem(), Math.max(1, Math.min(64, (int) (v.wood / 4)))));
        }
    }

    private static void house(ServerLevel l, Style s, int x0, int y0, int z0, boolean storage, Village v) {
        BlockState planks = s.planks().defaultBlockState();
        BlockState logs = s.log().defaultBlockState();
        for (int dx = 0; dx < 5; dx++) {
            for (int dz = 0; dz < 5; dz++) {
                int x = x0 + dx;
                int z = z0 + dz;
                foundation(l, x, y0, z, s.base());
                put(l, x, y0, z, planks);
                boolean edge = dx == 0 || dx == 4 || dz == 0 || dz == 4;
                boolean corner = (dx == 0 || dx == 4) && (dz == 0 || dz == 4);
                if (edge) {
                    for (int h = 1; h <= 3; h++) {
                        put(l, x, y0 + h, z, corner ? logs : planks);
                    }
                }
                put(l, x, y0 + 4, z, planks);
            }
        }
        for (int dx = 1; dx <= 3; dx++) {
            for (int dz = 1; dz <= 3; dz++) {
                put(l, x0 + dx, y0 + 5, z0 + dz, planks);
            }
        }
        BlockState pane = Blocks.GLASS_PANE.defaultBlockState();
        put(l, x0, y0 + 2, z0 + 2, pane);
        put(l, x0 + 4, y0 + 2, z0 + 2, pane);
        put(l, x0 + 2, y0 + 2, z0 + 4, pane);
        // Puerta
        BlockState door = s.door().defaultBlockState().setValue(DoorBlock.FACING, Direction.NORTH);
        put(l, x0 + 2, y0 + 1, z0, door.setValue(DoorBlock.HALF, DoubleBlockHalf.LOWER));
        put(l, x0 + 2, y0 + 2, z0, door.setValue(DoorBlock.HALF, DoubleBlockHalf.UPPER));

        if (!storage) {
            // Dos camas (los aldeanos las reclaman como hogar)
            for (int bx : new int[]{1, 3}) {
                BlockState foot = Blocks.RED_BED.defaultBlockState()
                        .setValue(BedBlock.FACING, Direction.SOUTH).setValue(BedBlock.PART, BedPart.FOOT);
                BlockState head = Blocks.RED_BED.defaultBlockState()
                        .setValue(BedBlock.FACING, Direction.SOUTH).setValue(BedBlock.PART, BedPart.HEAD);
                put(l, x0 + bx, y0 + 1, z0 + 2, foot);
                put(l, x0 + bx, y0 + 1, z0 + 3, head);
            }
            put(l, x0 + 2, y0 + 1, z0 + 3, Blocks.LANTERN.defaultBlockState());
        } else {
            // Almacen comunitario fisico: cofres y barril
            BlockPos c1 = new BlockPos(x0 + 1, y0 + 1, z0 + 3);
            BlockPos c2 = new BlockPos(x0 + 3, y0 + 1, z0 + 3);
            put(l, c1.getX(), c1.getY(), c1.getZ(), Blocks.CHEST.defaultBlockState());
            put(l, c2.getX(), c2.getY(), c2.getZ(), Blocks.CHEST.defaultBlockState());
            put(l, x0 + 2, y0 + 1, z0 + 3, Blocks.BARREL.defaultBlockState());
            put(l, x0 + 3, y0 + 1, z0 + 1, Blocks.LANTERN.defaultBlockState());
        }
    }

    private static void farm(ServerLevel l, Style s, int x0, int y0, int z0, java.util.Random rnd) {
        for (int dx = 0; dx < 5; dx++) {
            for (int dz = 0; dz < 5; dz++) {
                int x = x0 + dx;
                int z = z0 + dz;
                foundation(l, x, y0, z, Blocks.DIRT);
                boolean inner = dx >= 1 && dx <= 3 && dz >= 1 && dz <= 3;
                if (!inner) {
                    put(l, x, y0, z, Blocks.GRASS_BLOCK.defaultBlockState());
                } else if (dx == 2 && dz == 2) {
                    put(l, x, y0, z, Blocks.WATER.defaultBlockState());
                } else {
                    put(l, x, y0, z, Blocks.FARMLAND.defaultBlockState().setValue(FarmBlock.MOISTURE, 7));
                    put(l, x, y0 + 1, z, Blocks.WHEAT.defaultBlockState()
                            .setValue(BlockStateProperties.AGE_7, 3 + rnd.nextInt(5)));
                }
            }
        }
        for (int dx = 0; dx < 5; dx++) {
            for (int dz = 0; dz < 5; dz++) {
                boolean edge = dx == 0 || dx == 4 || dz == 0 || dz == 4;
                if (!edge) continue;
                int x = x0 + dx;
                int z = z0 + dz;
                if (dx == 2 && dz == 0) {
                    put(l, x, y0 + 1, z, s.gate().defaultBlockState().setValue(FenceGateBlock.FACING, Direction.NORTH));
                } else if (dx == 4 && dz == 4) {
                    // El compostador es el puesto de trabajo de los agricultores
                    put(l, x, y0 + 1, z, Blocks.COMPOSTER.defaultBlockState());
                } else {
                    put(l, x, y0 + 1, z, s.fence().defaultBlockState());
                }
            }
        }
    }

    private static void plaza(ServerLevel l, Style s, int x0, int y0, int z0) {
        for (int dx = 0; dx < 5; dx++) {
            for (int dz = 0; dz < 5; dz++) {
                int x = x0 + dx;
                int z = z0 + dz;
                foundation(l, x, y0, z, Blocks.DIRT);
                boolean edge = dx == 0 || dx == 4 || dz == 0 || dz == 4;
                put(l, x, y0, z, (edge ? Blocks.STONE_BRICKS : Blocks.POLISHED_ANDESITE).defaultBlockState());
            }
        }
        for (int[] c : new int[][]{{0, 0}, {4, 0}, {0, 4}, {4, 4}}) {
            int x = x0 + c[0];
            int z = z0 + c[1];
            put(l, x, y0 + 1, z, s.fence().defaultBlockState());
            put(l, x, y0 + 2, z, s.fence().defaultBlockState());
            put(l, x, y0 + 3, z, Blocks.LANTERN.defaultBlockState());
        }
        put(l, x0 + 2, y0 + 1, z0 + 2, Blocks.BELL.defaultBlockState());
    }

    // ------------------------------------------------------------------ caminos e iluminacion

    private static void pathToCenter(ServerLevel l, int sx, int sz, BlockPos center) {
        int x = sx;
        int z = sz;
        placePath(l, x, z);
        int guard = 0;
        while ((x != center.getX() || z != center.getZ()) && guard++ < 160) {
            int dx = center.getX() - x;
            int dz = center.getZ() - z;
            if (dx != 0 && Math.abs(dx) >= Math.abs(dz)) {
                x += Integer.signum(dx);
            } else {
                z += Integer.signum(dz);
            }
            placePath(l, x, z);
        }
    }

    private static void placePath(ServerLevel l, int x, int z) {
        if (!l.isLoaded(new BlockPos(x, 64, z))) return;
        int y = l.getHeight(SURFACE, x, z) - 1;
        BlockPos p = new BlockPos(x, y, z);
        BlockState st = l.getBlockState(p);
        if (st.is(Blocks.GRASS_BLOCK) || st.is(Blocks.DIRT) || st.is(Blocks.COARSE_DIRT) || st.is(Blocks.PODZOL)) {
            BlockState above = l.getBlockState(p.above());
            if (above.isAir() || above.canBeReplaced()) {
                if (!above.isAir()) l.setBlock(p.above(), Blocks.AIR.defaultBlockState(), 3);
                l.setBlock(p, Blocks.DIRT_PATH.defaultBlockState(), 3);
            }
        }
    }

    private static void lampPost(ServerLevel l, Style s, int x, int z) {
        if (!l.isLoaded(new BlockPos(x, 64, z))) return;
        int y = l.getHeight(SURFACE, x, z);
        BlockPos ground = new BlockPos(x, y - 1, z);
        BlockState gs = l.getBlockState(ground);
        if (gs.isAir() || !gs.getFluidState().isEmpty() || !gs.isFaceSturdy(l, ground, Direction.UP)) return;
        if (!l.getBlockState(new BlockPos(x, y, z)).isAir()) return;
        put(l, x, y, z, s.fence().defaultBlockState());
        put(l, x, y + 1, z, s.fence().defaultBlockState());
        put(l, x, y + 2, z, Blocks.LANTERN.defaultBlockState());
    }

    // ------------------------------------------------------------------ daños

    /** Una construccion se considera dañada si le faltan varias piezas clave. */
    public static boolean damaged(ServerLevel l, Building b) {
        int x0 = b.pos.getX();
        int y0 = b.pos.getY();
        int z0 = b.pos.getZ();
        if (!l.isLoaded(b.pos) || !l.isLoaded(b.pos.offset(4, 0, 4))) return false;
        int missing = 0;
        switch (b.type) {
            case HOUSE, STORAGE -> {
                int[][] keys = {{0, 1, 0}, {4, 1, 0}, {0, 1, 4}, {4, 1, 4}, {2, 4, 2}};
                for (int[] k : keys) {
                    BlockState st = l.getBlockState(new BlockPos(x0 + k[0], y0 + k[1], z0 + k[2]));
                    if (st.isAir() || st.canBeReplaced()) missing++;
                }
            }
            case FARM -> {
                int[][] keys = {{0, 1, 0}, {4, 1, 0}, {0, 1, 4}};
                for (int[] k : keys) {
                    BlockState st = l.getBlockState(new BlockPos(x0 + k[0], y0 + k[1], z0 + k[2]));
                    if (!(st.getBlock() instanceof FenceBlock)) missing++;
                }
            }
            default -> {
                return false;
            }
        }
        return missing >= 2;
    }

    // ------------------------------------------------------------------ utilidades

    private static void put(ServerLevel l, int x, int y, int z, BlockState st) {
        BlockPos p = new BlockPos(x, y, z);
        if (capture != null) {
            capture.add(new Object[]{p, st});
            return;
        }
        if (repairMode ? !Protection.canRepair(l, p) : !Protection.canOverwrite(l, p)) return;
        l.setBlock(p, st, 3);
    }

    private static void clear(ServerLevel l, int x, int y, int z, int w, int h, int d) {
        BlockState air = Blocks.AIR.defaultBlockState();
        for (int dx = 0; dx < w; dx++) {
            for (int dy = 0; dy < h; dy++) {
                for (int dz = 0; dz < d; dz++) {
                    BlockPos p = new BlockPos(x + dx, y + dy, z + dz);
                    if (l.getBlockState(p).isAir() || !Protection.canOverwrite(l, p)) continue;
                    if (capture != null) {
                        capture.add(new Object[]{p, air});
                    } else {
                        l.setBlock(p, air, 3);
                    }
                }
            }
        }
    }

    /** Rellena huecos bajo la construccion (maximo 4 bloques) para que no quede en el aire. */
    private static void foundation(ServerLevel l, int x, int y0, int z, Block fill) {
        for (int y = y0 - 1; y >= y0 - 4; y--) {
            BlockPos p = new BlockPos(x, y, z);
            BlockState st = l.getBlockState(p);
            if (st.isAir() || st.canBeReplaced() || !st.getFluidState().isEmpty()) {
                put(l, x, y, z, fill.defaultBlockState());
            } else {
                break;
            }
        }
    }
}
