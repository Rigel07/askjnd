package com.alive.mod.village;

import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.registries.ForgeRegistries;

/**
 * Proteccion de lo que NO debe destruir una obra de aldeanos: cofres y cualquier bloque con inventario o datos,
 * bloques de otros mods y construcciones de jugadores (bloques "fabricados").
 */
public final class Protection {
    private static final String[] MAN_MADE = {"planks", "brick", "glass", "wool", "carpet", "door", "bed", "slab", "stairs",
            "fence", "wall", "torch", "lantern", "rail", "concrete", "table", "furnace", "smoker", "barrel", "ladder", "sign",
            "button", "lever", "plate", "banner", "polished", "chiseled", "cut_", "iron_block", "gold_block", "diamond_block",
            "emerald_block", "redstone", "piston", "hopper", "dropper", "dispenser", "observer", "bookshelf", "lectern",
            "anvil", "cauldron", "composter", "campfire", "bell", "scaffolding", "pane", "bars", "frame", "pot", "head", "skull"};

    private Protection() {
    }

    private static String namespace(BlockState st) {
        ResourceLocation id = ForgeRegistries.BLOCKS.getKey(st.getBlock());
        return id == null ? "" : id.getNamespace();
    }

    private static String path(BlockState st) {
        ResourceLocation id = ForgeRegistries.BLOCKS.getKey(st.getBlock());
        return id == null ? "" : id.getPath();
    }

    /** Terreno natural que una obra nueva puede sustituir (ademas de aire, plantas, hojas y fluidos). */
    public static boolean isNaturalGround(BlockState st) {
        if (st.is(BlockTags.DIRT) || st.is(BlockTags.BASE_STONE_OVERWORLD) || st.is(BlockTags.SAND)) return true;
        Block b = st.getBlock();
        if (b == Blocks.GRAVEL || b == Blocks.CLAY || b == Blocks.SNOW_BLOCK || b == Blocks.ICE || b == Blocks.PACKED_ICE
                || b == Blocks.MUD || b == Blocks.MOSS_BLOCK || b == Blocks.SANDSTONE || b == Blocks.RED_SANDSTONE
                || b == Blocks.CALCITE || b == Blocks.DRIPSTONE_BLOCK) {
            return true;
        }
        String p = path(st);
        return p.equals("terracotta") || (p.endsWith("_terracotta") && !p.contains("glazed")) || p.endsWith("_ore");
    }

    /** Bloque claramente colocado por un jugador (o un mod): su zona no es un solar valido. */
    public static boolean isManMade(BlockState st) {
        if (st.isAir() || !st.getFluidState().isEmpty() || st.canBeReplaced() || st.is(BlockTags.LEAVES)) return false;
        if (st.hasBlockEntity() || !namespace(st).equals("minecraft")) return true;
        if (isNaturalGround(st) || st.is(BlockTags.LOGS)) return false;
        String p = path(st);
        for (String s : MAN_MADE) {
            if (p.contains(s)) return true;
        }
        return false;
    }

    /** Una obra NUEVA puede sobrescribir esta posicion. */
    public static boolean canOverwrite(ServerLevel l, BlockPos p) {
        BlockState st = l.getBlockState(p);
        if (st.isAir()) return true;
        if (st.hasBlockEntity() || l.getBlockEntity(p) != null) return false;
        if (!namespace(st).equals("minecraft")) return false;
        if (st.canBeReplaced() || st.is(BlockTags.LEAVES) || !st.getFluidState().isEmpty()) return true;
        return isNaturalGround(st);
    }

    /** Una REPARACION solo rellena huecos: nunca pisa lo que haya (muebles o cambios del jugador). */
    public static boolean canRepair(ServerLevel l, BlockPos p) {
        BlockState st = l.getBlockState(p);
        return st.isAir() || (st.canBeReplaced() && !st.hasBlockEntity() && namespace(st).equals("minecraft"));
    }

    /** Hay algo fabricado (o un bloque con datos) en el area? Se usa para no construir encima de casas del jugador. */
    public static boolean hasPlayerStructure(ServerLevel l, int x0, int z0, int w, int d, int yFrom, int yTo) {
        for (int x = x0; x < x0 + w; x++) {
            for (int z = z0; z < z0 + d; z++) {
                for (int y = yFrom; y <= yTo; y++) {
                    if (isManMade(l.getBlockState(new BlockPos(x, y, z)))) return true;
                }
            }
        }
        return false;
    }
}
