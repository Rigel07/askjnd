package com.alive.mod.village;

import com.alive.mod.config.AliveConfig;
import com.alive.mod.data.Building;
import com.alive.mod.data.BuildingType;
import com.alive.mod.data.Village;
import com.alive.mod.data.VillageData;
import com.alive.mod.economy.EconomySim;
import com.alive.mod.trade.CaravanManager;
import com.alive.mod.villager.Personality;
import com.alive.mod.villager.Role;
import com.alive.mod.villager.VillagerLife;
import net.minecraft.core.BlockPos;
import net.minecraft.core.GlobalPos;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.ai.memory.MemoryModuleType;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.npc.VillagerProfession;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;

import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

/**
 * Orquesta la vida de las aldeas.
 *
 * Simulacion ACTIVA: si el centro de la aldea esta cerca de un jugador se leen los aldeanos reales,
 * se ejecutan sus rutinas y se aplican cambios fisicos (colonos, construcciones, reparaciones).
 * Simulacion ABSTRACTA: si esta lejos, solo se actualizan numeros segun el tiempo transcurrido.
 */
public final class VillageManager {
    private static final long STEP = 6000L;
    private static final int MAX_STEPS = 120;
    private static final int PER_PASS = 6;
    private static final Map<ResourceKey<Level>, Integer> CURSORS = new HashMap<>();

    private VillageManager() {
    }

    public static void clear() {
        CURSORS.clear();
    }

    /** Registra el asentamiento al que pertenece un aldeano (o crea uno nuevo). Barato: sin busquedas de entidades. */
    public static void onVillagerJoin(ServerLevel level, Villager villager) {
        VillagerLife.personality(villager);
        ConstructionManager.dropCarry(villager);
        VillageData data = VillageData.get(level);
        BlockPos p = villager.blockPosition();
        if (data.findNearest(p, 96) == null) {
            long now = level.getGameTime();
            Village v = new Village(UUID.randomUUID(), Village.randomName(level.getRandom()), p, now);
            v.log(now, "Se registra el asentamiento " + v.name + ".");
            data.add(v);
        }
    }

    /** Una pasada de simulacion. all=true procesa todas las aldeas (comando /alive advance). */
    public static void process(ServerLevel level, boolean all) {
        VillageData data = VillageData.get(level);
        List<Village> list = data.list();
        if (list.isEmpty()) return;
        int n = list.size();
        int start = all ? 0 : CURSORS.getOrDefault(level.dimension(), 0) % n;
        int count = all ? n : Math.min(PER_PASS, n);
        for (int i = 0; i < count; i++) {
            processOne(level, data, list, list.get((start + i) % n));
        }
        if (!all) CURSORS.put(level.dimension(), (start + count) % n);
        data.setDirty();
    }

    private static AABB villageBox(Village v) {
        int r = Math.max(48, AliveConfig.MAX_EXPANSION.get() + 16);
        return new AABB(v.center).inflate(r, 40, r);
    }

    private static void processOne(ServerLevel level, VillageData data, List<Village> all, Village v) {
        long now = level.getGameTime();
        boolean active = level.isPositionEntityTicking(v.center);
        boolean personalities = AliveConfig.PERSONALITIES.get();
        boolean social = AliveConfig.SOCIAL.get();

        if (active) {
            List<Villager> vs = level.getEntitiesOfClass(Villager.class, villageBox(v), Villager::isAlive);
            sync(level, v, vs, personalities, social);
            VillagerLife.tickBehaviors(level, v.center, vs, social, personalities, AliveConfig.MAX_EXPANSION.get());
        }

        boolean growth = AliveConfig.VILLAGE_GROWTH.get() && v.hasBell && v.population >= 3;
        long elapsed = now - v.lastSim;
        if (elapsed >= STEP) {
            long total = elapsed / STEP;
            int steps = (int) Math.min(MAX_STEPS, total);
            if (active || AliveConfig.OFFLINE_SIM.get()) {
                for (int i = 0; i < steps; i++) {
                    EconomySim.step(v, growth, v.lastSim + (i + 1L) * STEP);
                }
            }
            v.lastSim = total > MAX_STEPS ? now : v.lastSim + steps * STEP;
        }

        if (active) applyWorld(level, v, growth, now);
        trade(level, all, v, now);
    }

    /** Lee el estado real de los aldeanos cargados. */
    private static void sync(ServerLevel level, Village v, List<Villager> vs, boolean personalities, boolean social) {
        int[] roles = new int[Role.values().length];
        double ethic = 0;
        double coh = 0;
        double gen = 0;
        int n = 0;
        BlockPos meet = null;
        for (Villager vl : vs) {
            n++;
            Personality p = VillagerLife.personality(vl);
            Role r = VillagerLife.refreshRole(vl);
            roles[r.ordinal()]++;
            if (personalities) {
                ethic += p == Personality.TRABAJADOR ? 1.3 : (p == Personality.INDEPENDIENTE ? 0.95 : 1.0);
                if (p == Personality.GENEROSO) gen += 1;
            } else {
                ethic += 1.0;
            }
            if (social && p != Personality.INDEPENDIENTE) {
                coh += Math.min(3, VillagerLife.friends(vl)) / 3.0;
            }
            Optional<GlobalPos> mp = vl.getBrain().getMemory(MemoryModuleType.MEETING_POINT);
            if (mp.isPresent() && mp.get().dimension() == level.dimension()) {
                v.hasBell = true;
                if (meet == null) meet = mp.get().pos();
            }
        }
        v.population = n;
        System.arraycopy(roles, 0, v.roles, 0, roles.length);
        if (n > 0) {
            v.workEthic = ethic / n;
            v.cohesion = coh / n;
            v.generosity = gen / n;
            v.peakPopulation = Math.max(v.peakPopulation, n);
            if (v.baseCapacity == 0 && n >= 3) v.baseCapacity = Math.max(6, n + 2);
        }
        if (meet != null) {
            long dx = meet.getX() - v.center.getX();
            long dz = meet.getZ() - v.center.getZ();
            if (dx * dx + dz * dz < 80L * 80L) v.center = meet;
        }
    }

    /** Cambios fisicos en el mundo: solo cuando la zona esta activa. */
    private static void applyWorld(ServerLevel level, Village v, boolean growth, long now) {
        RandomSource rnd = level.getRandom();

        // Colonos que llegaron mientras no mirabas
        int spawned = 0;
        while (v.pendingSpawns > 0 && spawned < 2) {
            if (!spawnVillager(level, v, rnd)) break;
            v.pendingSpawns--;
            spawned++;
        }

        // Familias que se marcharon
        if (v.pendingEmigrants > 0) {
            List<Villager> vs = level.getEntitiesOfClass(Villager.class, villageBox(v), Villager::isAlive);
            if (!vs.isEmpty()) {
                vs.sort(Comparator.comparingInt(x -> x.getVillagerData().getProfession() == VillagerProfession.NONE ? 0 : 1));
                vs.get(0).discard();
            }
            v.pendingEmigrants--;
        }

        if (!growth) return;

        // Construcciones pendientes: se inicia UNA obra cada vez (la ejecutan los constructores, ver ConstructionManager)
        if (v.pendingBuilds > 0 && now >= v.noSpaceUntil && v.underConstruction() == null) {
            BuildingType type = StructureBuilder.chooseType(v);
            if (StructureBuilder.place(level, v, type, rnd)) {
                v.pendingBuilds--;
                v.buildFailures = 0;
                v.log(now, AliveConfig.PROGRESSIVE_BUILD.get()
                        ? "Los aldeanos preparan el solar de una nueva " + type.label + "."
                        : "Los aldeanos construyen una nueva " + type.label + ".");
            } else if (++v.buildFailures >= 3) {
                v.pendingBuilds = 0;
                v.buildFailures = 0;
                v.noSpaceUntil = now + 7L * 24000L;
                v.log(now, "No queda terreno adecuado: la aldea alcanza su límite natural por ahora.");
            }
        }

        // Reparaciones
        if (v.materials >= 6 && v.wood >= 8) {
            for (Building b : v.buildings) {
                if (b.isComplete() && StructureBuilder.damaged(level, b)) {
                    StructureBuilder.build(level, b, v);
                    v.materials -= 6;
                    v.wood -= 8;
                    v.log(now, "Reconstrucción: los aldeanos reparan una " + b.type.label + " dañada.");
                    break;
                }
            }
        }
    }

    private static boolean spawnVillager(ServerLevel level, Village v, RandomSource rnd) {
        int x = v.center.getX() + rnd.nextInt(17) - 8;
        int z = v.center.getZ() + rnd.nextInt(17) - 8;
        if (!level.isLoaded(new BlockPos(x, 64, z))) return false;
        int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
        return EntityType.VILLAGER.spawn(level, new BlockPos(x, y, z), MobSpawnType.MOB_SUMMONED) != null;
    }

    /**
     * Comercio: una aldea con excedente envia mercancias a la vecina mas necesitada. La capacidad depende de los
     * transportistas y de la generosidad. Se crea una CARAVANA (ver CaravanManager): la mercancia sale del almacen
     * de origen al partir y llega a la economia del destino solo cuando la caravana entrega.
     */
    private static void trade(ServerLevel level, List<Village> all, Village a, long now) {
        if (!AliveConfig.TRADE.get() || a.population < 3 || now - a.lastTrade < 24000L) return;
        if (CaravanManager.hasActiveFrom(level, a.id)) return;
        a.lastTrade = now;
        Village best = null;
        double bestNeed = 0;
        for (Village b : all) {
            if (b == a || b.population < 3) continue;
            long dx = b.center.getX() - a.center.getX();
            long dz = b.center.getZ() - a.center.getZ();
            if (dx * dx + dz * dz > 400L * 400L) continue;
            double need = b.population * 8.0 - b.food;
            if (need > bestNeed) {
                bestNeed = need;
                best = b;
            }
        }
        if (best == null || bestNeed < 10) return;
        double surplus = a.food - a.population * 15.0;
        if (surplus < 10) return;
        double cap = 20 + a.role(Role.TRANSPORTER) * 10 + a.generosity * a.population * 5;
        double amount = Math.min(cap, Math.min(surplus, bestNeed));
        amount = EconomySim.takeFood(a, amount);
        if (amount <= 0) return;
        if (!CaravanManager.launch(level, a, best, amount, now)) {
            EconomySim.deliverFood(a, amount);
            return;
        }
        if (a.routes.add(best.id)) {
            a.log(now, "Se establece una ruta comercial con " + best.name + ".");
            best.routes.add(a.id);
            best.log(now, "Se establece una ruta comercial con " + a.name + ".");
        }
        a.log(now, "Una caravana parte hacia " + best.name + " con " + Math.round(amount) + " de comida.");
    }
}
