package com.alive.mod;

import com.alive.mod.config.AliveConfig;
import com.alive.mod.events.AliveEvents;
import com.mojang.logging.LogUtils;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import org.slf4j.Logger;

/**
 * Alive - A World Beyond You.
 * Clase principal: registra la configuracion (SERVER, por mundo) y los eventos.
 */
@Mod(AliveMod.MODID)
public class AliveMod {
    public static final String MODID = "alive";
    public static final Logger LOGGER = LogUtils.getLogger();

    public AliveMod() {
        ModLoadingContext.get().registerConfig(ModConfig.Type.SERVER, AliveConfig.SPEC, "alive-server.toml");
        MinecraftForge.EVENT_BUS.register(new AliveEvents());
    }
}
