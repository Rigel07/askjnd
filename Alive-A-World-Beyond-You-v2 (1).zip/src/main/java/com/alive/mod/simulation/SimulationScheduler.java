package com.alive.mod.simulation;

import com.alive.mod.animal.EcosystemManager;
import com.alive.mod.config.AliveConfig;
import com.alive.mod.trade.CaravanManager;
import com.alive.mod.village.ConstructionManager;
import com.alive.mod.village.VillageManager;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraftforge.server.ServerLifecycleHooks;

/**
 * Programador de la simulacion: nada se calcula en cada tick.
 * Pasada completa cada N segundos (config); reconciliacion de chunks cada 5 segundos.
 */
public final class SimulationScheduler {
    private static long counter = 0;

    private SimulationScheduler() {
    }

    public static void tick() {
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        if (server == null) return;
        counter++;
        int interval = Math.max(100, AliveConfig.SIM_INTERVAL_SECONDS.get() * 20);
        boolean full = counter % interval == 0;
        boolean quick = counter % 100 == 0;
        boolean second = counter % 20 == 0;
        if (!full && !quick && !second) return;
        for (ServerLevel level : server.getAllLevels()) {
            if (full) {
                VillageManager.process(level, false);
                EcosystemManager.process(level);
            }
            if (quick) {
                EcosystemManager.reconcile(level);
            }
            if (second) {
                ConstructionManager.tick(level);
                CaravanManager.tick(level);
            }
        }
    }

    /** Fuerza una pasada completa en un nivel (usado por /alive advance). */
    public static void forceFull(ServerLevel level) {
        VillageManager.process(level, true);
        EcosystemManager.process(level);
        CaravanManager.tick(level);
    }
}
