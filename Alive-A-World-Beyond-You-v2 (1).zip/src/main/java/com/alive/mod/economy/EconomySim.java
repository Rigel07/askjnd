package com.alive.mod.economy;

import com.alive.mod.config.AliveConfig;
import com.alive.mod.config.Seasons;
import com.alive.mod.data.BuildingType;
import com.alive.mod.data.Village;
import com.alive.mod.villager.Role;

/**
 * Economia abstracta de una aldea. Un "paso" equivale a 6000 ticks (un cuarto de dia de Minecraft).
 * Es matematica pura: no necesita chunks ni entidades cargadas.
 */
public final class EconomySim {
    public static final double COST_WOOD = 20;
    public static final double COST_STONE = 10;
    public static final double COST_MATERIALS = 8;
    private static final int[] MAX_BUILDINGS = {3, 8, 16, 28};

    private EconomySim() {
    }

    public static int capacity(Village v) {
        int base = Math.max(6, v.baseCapacity);
        int cap = base + v.countBuilt(BuildingType.HOUSE) * 2 + (v.stage - 1) * 2;
        return Math.min(AliveConfig.MAX_POPULATION.get(), cap);
    }

    public static int maxBuildings(int stage) {
        return MAX_BUILDINGS[Math.max(0, Math.min(MAX_BUILDINGS.length - 1, stage - 1))];
    }

    private static double clamp(double v, double max) {
        return Math.max(0.0, Math.min(max, v));
    }

    /** Un paso de simulacion. 'time' es el tick de juego al que corresponde el paso (para el historial). */
    public static void step(Village v, boolean growth, long time) {
        int pop = v.population;
        if (pop <= 0 && v.pendingSpawns <= 0) return;

        double speed = AliveConfig.GROWTH_SPEED.get() / 100.0;
        double season = Seasons.crop(time);
        double eth = v.workEthic * (1.0 + 0.1 * v.cohesion);

        double farmers = v.role(Role.FARMER);
        double gatherers = v.role(Role.GATHERER);
        double builders = v.role(Role.BUILDER);
        double artisans = v.role(Role.ARTISAN);
        double guards = v.role(Role.GUARD);

        // Produccion y consumo
        double foodIn = (farmers * 4.0 + gatherers * 1.5 + pop * 0.4) * eth * season;
        double foodOut = pop * 0.8;
        v.food = clamp(v.food + foodIn - foodOut, 3000);
        v.wood = clamp(v.wood + (gatherers * 2.0 + builders * 0.5 + pop * 0.4) * eth, 2000);
        v.stone = clamp(v.stone + (gatherers * 1.0 + builders * 0.3 + pop * 0.2) * eth, 2000);
        // Los guardianes consumen equipamiento
        v.materials = clamp(v.materials + (artisans * 1.5 + builders * 0.5 + pop * 0.15) * eth - guards * 0.3, 1000);

        // Escasez de alimentos y emigracion
        double intensity = AliveConfig.EVENT_INTENSITY.get();
        if (v.food < pop * 2.0) {
            v.scarceSteps++;
            if (!v.scarce && v.scarceSteps >= 3) {
                v.scarce = true;
                v.log(time, "Escasez de alimentos: el crecimiento se detiene.");
            }
        } else if (v.food > pop * 5.0) {
            v.scarceSteps = 0;
            if (v.scarce) {
                v.scarce = false;
                v.log(time, "Los almacenes se recuperan: termina la escasez.");
            }
        }
        if (v.scarce && intensity > 0 && v.food <= 1.0 && pop > 2) {
            int limit = Math.max(2, (int) (6.0 * 100.0 / intensity));
            if (v.scarceSteps >= limit) {
                v.scarceSteps = limit / 2;
                if (v.pendingSpawns > 0) {
                    v.pendingSpawns--;
                } else {
                    v.population--;
                    v.pendingEmigrants++;
                    v.log(time, "Emigración: una familia abandona la aldea por el hambre.");
                }
            }
        }

        if (!growth) return;

        // Llegada de colonos (necesita excedente de comida y vivienda)
        int cap = capacity(v);
        if (!v.scarce && v.food > pop * 6.0 && pop >= 2 && pop + v.pendingSpawns < cap) {
            v.growthProgress += 0.35 * speed * (1.0 + 0.1 * v.cohesion);
            if (v.growthProgress >= 1.0) {
                v.growthProgress -= 1.0;
                v.pendingSpawns++;
                v.log(time, "Llegan nuevos colonos.");
            }
        }

        // Preparacion de nuevas construcciones
        if (v.buildings.size() < maxBuildings(v.stage) && v.pendingBuilds < 2 && time >= v.noSpaceUntil) {
            v.buildProgress += 0.12 * (1.0 + builders * 0.8) * eth * speed;
            // Los materiales ya no se descuentan aqui: los constructores los retiran poco a poco durante la obra
            // (ver ConstructionManager). Basta con que la aldea los tenga para autorizar el proyecto.
            if (v.buildProgress >= 1.0 && v.wood >= COST_WOOD && v.stone >= COST_STONE && v.materials >= COST_MATERIALS) {
                v.buildProgress = 0;
                v.pendingBuilds++;
            }
        }

        // Etapa de desarrollo (nunca retrocede)
        int total = pop + v.pendingSpawns;
        int s = 1;
        if (total >= 8 && v.food >= 80) s = 2;
        if (total >= 16 && v.buildings.size() >= 6 && v.food >= 200) s = 3;
        if (total >= 26 && v.buildings.size() >= 12 && v.food >= 400) s = 4;
        if (s > v.stage) {
            v.stage = s;
            v.log(time, "La aldea evoluciona: ahora es una " + stageName(s) + ".");
        }
        v.peakPopulation = Math.max(v.peakPopulation, total);
    }

    /** Retira mercancia (comida) de una aldea para cargar una caravana. Devuelve lo realmente retirado. */
    public static double takeFood(Village v, double amount) {
        double taken = Math.max(0.0, Math.min(amount, v.food));
        v.food -= taken;
        return taken;
    }

    /** Entrega mercancia (comida) a una aldea. Unico punto de entrada de las caravanas a la economia. */
    public static void deliverFood(Village v, double amount) {
        v.food = clamp(v.food + Math.max(0.0, amount), 3000);
    }

    public static String stageName(int stage) {
        switch (stage) {
            case 1:
                return "aldea pequeña";
            case 2:
                return "aldea establecida";
            case 3:
                return "aldea próspera";
            default:
                return "aldea avanzada";
        }
    }
}
