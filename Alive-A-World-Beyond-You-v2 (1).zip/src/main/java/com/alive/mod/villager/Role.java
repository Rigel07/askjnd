package com.alive.mod.villager;

/** Funciones adicionales de los aldeanos (se suman a las profesiones vanilla). */
public enum Role {
    FARMER("Agricultor"),
    BUILDER("Constructor"),
    TRANSPORTER("Transportista"),
    GATHERER("Recolector"),
    GUARD("Guardián"),
    TRADER("Comerciante"),
    EXPLORER("Explorador"),
    ARTISAN("Artesano");

    public final String label;

    Role(String label) {
        this.label = label;
    }
}
