package com.alive.mod.villager;

import net.minecraft.core.BlockPos;
import net.minecraft.core.GlobalPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.ai.behavior.EntityTracker;
import net.minecraft.world.entity.ai.memory.MemoryModuleType;
import net.minecraft.world.entity.ai.memory.WalkTarget;
import net.minecraft.world.entity.ai.util.LandRandomPos;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.npc.VillagerProfession;
import net.minecraft.world.phys.Vec3;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Personalidad, funcion, amistades y rutinas extra de los aldeanos.
 * Los datos se guardan en el NBT persistente de cada aldeano (se conservan al cerrar el juego).
 */
public final class VillagerLife {
    private static final String TAG_P = "alive_personality";
    private static final String TAG_R = "alive_role";
    private static final String TAG_F = "alive_friends";

    private VillagerLife() {
    }

    public static Personality personality(Villager v) {
        CompoundTag t = v.getPersistentData();
        if (!t.contains(TAG_P)) {
            t.putInt(TAG_P, v.getRandom().nextInt(Personality.values().length));
        }
        return Personality.byId(t.getInt(TAG_P));
    }

    /** Recalcula la funcion del aldeano segun su profesion y personalidad y la guarda. */
    public static Role refreshRole(Villager v) {
        Role r = computeRole(v, personality(v));
        v.getPersistentData().putInt(TAG_R, r.ordinal());
        return r;
    }

    public static Role computeRole(Villager v, Personality p) {
        VillagerProfession prof = v.getVillagerData().getProfession();
        if (prof == VillagerProfession.FARMER) return Role.FARMER;
        if (prof == VillagerProfession.FISHERMAN || prof == VillagerProfession.SHEPHERD
                || prof == VillagerProfession.BUTCHER) return Role.GATHERER;
        if (prof == VillagerProfession.ARMORER || prof == VillagerProfession.WEAPONSMITH
                || prof == VillagerProfession.TOOLSMITH || prof == VillagerProfession.MASON
                || prof == VillagerProfession.LEATHERWORKER || prof == VillagerProfession.FLETCHER
                || prof == VillagerProfession.CARTOGRAPHER) return Role.ARTISAN;
        if (prof == VillagerProfession.CLERIC || prof == VillagerProfession.LIBRARIAN) return Role.TRADER;
        // Sin profesion (o nitwit): la funcion depende de la personalidad
        switch (p) {
            case TRABAJADOR:
                return Role.BUILDER;
            case CURIOSO:
                return Role.EXPLORER;
            case CAUTELOSO:
                return Role.GUARD;
            case GENEROSO:
                return Role.TRANSPORTER;
            case SOCIABLE:
                return Role.TRADER;
            default:
                return Role.GATHERER;
        }
    }

    // ---------------------------------------------------------------- amistades

    public static void befriend(Villager a, Villager b, int amount) {
        add(a, b.getUUID(), amount);
        add(b, a.getUUID(), amount);
    }

    private static void add(Villager v, UUID other, int amount) {
        CompoundTag t = v.getPersistentData();
        ListTag list = t.getList(TAG_F, Tag.TAG_COMPOUND);
        String id = other.toString();
        for (int i = 0; i < list.size(); i++) {
            CompoundTag c = list.getCompound(i);
            if (c.getString("id").equals(id)) {
                c.putInt("v", Math.min(100, c.getInt("v") + amount));
                t.put(TAG_F, list);
                return;
            }
        }
        if (list.size() >= 6) {
            int low = 0;
            for (int i = 1; i < list.size(); i++) {
                if (list.getCompound(i).getInt("v") < list.getCompound(low).getInt("v")) low = i;
            }
            list.remove(low);
        }
        CompoundTag c = new CompoundTag();
        c.putString("id", id);
        c.putInt("v", amount);
        list.add(c);
        t.put(TAG_F, list);
    }

    /** Numero de amigos (relaciones con valor suficiente). */
    public static int friends(Villager v) {
        ListTag list = v.getPersistentData().getList(TAG_F, Tag.TAG_COMPOUND);
        int n = 0;
        for (int i = 0; i < list.size(); i++) {
            if (list.getCompound(i).getInt("v") >= 5) n++;
        }
        return n;
    }

    // ---------------------------------------------------------------- rutinas

    /**
     * Rutinas extra, ejecutadas solo en intervalos (no cada tick). Usan la memoria WALK_TARGET del cerebro vanilla.
     */
    public static void tickBehaviors(ServerLevel level, BlockPos center, List<Villager> villagers,
                                     boolean social, boolean personalities, int maxRange) {
        long dt = level.getDayTime() % 24000L;
        boolean day = dt < 11000L;
        RandomSource rnd = level.getRandom();
        int acted = 0;
        double range2 = (double) maxRange * maxRange;

        for (Villager v : villagers) {
            if (acted >= 8) break;
            if (!v.isAlive() || v.isBaby() || v.isSleeping()) continue;
            Personality p = personality(v);
            Role r = refreshRole(v);

            // Sociabilidad: busca a otro aldeano cercano y, si esta cerca, se hacen amigos
            if (social && day) {
                float chance = personalities ? (p == Personality.SOCIABLE ? 0.5f : (p == Personality.INDEPENDIENTE ? 0.05f : 0.2f)) : 0.2f;
                if (rnd.nextFloat() < chance) {
                    Villager other = null;
                    for (Villager o : villagers) {
                        if (o != v && o.isAlive() && !o.isBaby() && v.distanceToSqr(o) < 196.0D) {
                            if (other == null || rnd.nextInt(3) == 0) other = o;
                        }
                    }
                    if (other != null) {
                        if (v.distanceToSqr(other) < 9.0D) {
                            befriend(v, other, p == Personality.SOCIABLE ? 2 : 1);
                        } else {
                            v.getBrain().setMemory(MemoryModuleType.WALK_TARGET,
                                    new WalkTarget(new EntityTracker(other, true), 0.5F, 2));
                            acted++;
                            continue;
                        }
                    }
                }
            }

            if (!personalities) continue;

            // Curiosos y exploradores: pasean por los alrededores
            if ((p == Personality.CURIOSO || r == Role.EXPLORER) && day && !level.isRaining() && rnd.nextFloat() < 0.3f) {
                Vec3 pos = LandRandomPos.getPos(v, 24, 8);
                if (pos != null && pos.distanceToSqr(center.getX(), center.getY(), center.getZ()) <= range2) {
                    v.getBrain().setMemory(MemoryModuleType.WALK_TARGET, new WalkTarget(pos, 0.5F, 2));
                    acted++;
                    continue;
                }
            }

            // Cautelosos: se refugian en casa con mal tiempo o al caer la tarde
            if (p == Personality.CAUTELOSO && (level.isRaining() || dt >= 11500L)) {
                Optional<GlobalPos> home = v.getBrain().getMemory(MemoryModuleType.HOME);
                if (home.isPresent() && home.get().dimension() == level.dimension()
                        && v.blockPosition().distSqr(home.get().pos()) > 16.0D) {
                    v.getBrain().setMemory(MemoryModuleType.WALK_TARGET, new WalkTarget(home.get().pos(), 0.6F, 1));
                    acted++;
                    continue;
                }
            }

            // Guardianes: patrullan alrededor del centro al anochecer
            if (r == Role.GUARD && dt >= 12000L && dt < 15000L && rnd.nextFloat() < 0.5f) {
                Vec3 pos = LandRandomPos.getPosTowards(v, 14, 6, Vec3.atCenterOf(center));
                if (pos != null) {
                    v.getBrain().setMemory(MemoryModuleType.WALK_TARGET, new WalkTarget(pos, 0.5F, 2));
                    acted++;
                }
            }
        }
    }
}
