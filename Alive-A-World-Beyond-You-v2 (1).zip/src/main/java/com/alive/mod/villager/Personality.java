package com.alive.mod.villager;

/** Personalidades de aldeano. Cada una tiene efectos reales en comportamiento o produccion. */
public enum Personality {
    TRABAJADOR("Trabajador"),
    CURIOSO("Curioso"),
    SOCIABLE("Sociable"),
    CAUTELOSO("Cauteloso"),
    INDEPENDIENTE("Independiente"),
    GENEROSO("Generoso");

    public final String label;

    Personality(String label) {
        this.label = label;
    }

    public static Personality byId(int id) {
        Personality[] all = values();
        return all[Math.floorMod(id, all.length)];
    }
}
