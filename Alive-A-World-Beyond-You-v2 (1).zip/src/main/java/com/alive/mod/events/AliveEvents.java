package com.alive.mod.events;

import com.alive.mod.animal.AnimalGoals;
import com.alive.mod.animal.EcosystemManager;
import com.alive.mod.command.AliveCommand;
import com.alive.mod.simulation.SimulationScheduler;
import com.alive.mod.trade.CaravanManager;
import com.alive.mod.village.ConstructionManager;
import com.alive.mod.village.VillageManager;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.npc.Villager;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.living.BabyEntitySpawnEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.level.ChunkEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

/** Punto unico de enlace con los eventos de Forge (solo logica de servidor). */
public class AliveEvents {

    @SubscribeEvent
    public void onEntityJoin(EntityJoinLevelEvent e) {
        if (!(e.getLevel() instanceof ServerLevel level)) return;
        Entity entity = e.getEntity();
        // Mercaderes/animales de caravana guardados en un chunk: son fantasmas, el registro de la caravana manda
        if (CaravanManager.isGhost(entity)) {
            e.setCanceled(true);
            return;
        }
        try {
            if (entity instanceof Villager v) {
                VillageManager.onVillagerJoin(level, v);
            } else if (entity instanceof Mob m) {
                AnimalGoals.attach(m);
            }
        } catch (IllegalStateException ignored) {
            // configuracion aun no cargada: se ignora este aldeano/animal
        }
    }

    @SubscribeEvent
    public void onDeath(LivingDeathEvent e) {
        CaravanManager.onDeath(e.getEntity());
    }

    @SubscribeEvent
    public void onServerTick(TickEvent.ServerTickEvent e) {
        if (e.phase == TickEvent.Phase.END) {
            SimulationScheduler.tick();
        }
    }

    @SubscribeEvent
    public void onChunkLoad(ChunkEvent.Load e) {
        if (e.getLevel() instanceof ServerLevel level) {
            EcosystemManager.onChunkLoad(level, e.getChunk().getPos().toLong());
        }
    }

    @SubscribeEvent
    public void onBaby(BabyEntitySpawnEvent e) {
        try {
            AnimalGoals.onBreed(e);
        } catch (IllegalStateException ignored) {
            // configuracion aun no cargada
        }
    }

    @SubscribeEvent
    public void onCommands(RegisterCommandsEvent e) {
        AliveCommand.register(e.getDispatcher());
    }

    @SubscribeEvent
    public void onServerStopped(ServerStoppedEvent e) {
        VillageManager.clear();
        ConstructionManager.clear();
        EcosystemManager.clear();
    }
}
