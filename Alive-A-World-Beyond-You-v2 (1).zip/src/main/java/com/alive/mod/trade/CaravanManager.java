package com.alive.mod.trade;

import com.alive.mod.config.AliveConfig;
import com.alive.mod.data.Village;
import com.alive.mod.data.VillageData;
import com.alive.mod.economy.EconomySim;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.animal.horse.AbstractChestedHorse;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.npc.WanderingTrader;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;

import java.util.EnumSet;
import java.util.UUID;

/**
 * Caravanas comerciales fisicas.
 *
 * - El REGISTRO (Caravan) manda: posicion, parada de descanso, entrega y regreso se calculan con el tiempo de juego,
 *   tambien con las zonas descargadas (simulacion abstracta, sin cargar chunks).
 * - Si la posicion actual esta en una zona activa (jugador cerca) se materializa un mercader real (y un burro o mula
 *   con cofre si la carga es grande) que camina siguiendo la ruta. Al alejarse, se retiran las entidades.
 * - La mercancia sale de la aldea de origen al partir y llega a la economia del destino UNA sola vez (Caravan.delivered).
 */
public final class CaravanManager {
    public static final String TAG_ID = "alive_caravan";
    public static final String TAG_ROLE = "alive_caravan_role";
    private static final String TAG_WALK = "alive_caravan_walk";
    private static final int DESPAWN_AFTER = 4;
    private static final Heightmap.Types SURFACE = Heightmap.Types.MOTION_BLOCKING_NO_LEAVES;

    private CaravanManager() {
    }

    // ------------------------------------------------------------------ API economica

    public static boolean hasActiveFrom(ServerLevel level, UUID village) {
        for (Caravan c : CaravanData.get(level).list()) {
            if (c.origin.equals(village)) return true;
        }
        return false;
    }

    /** Crea la caravana. La mercancia YA ha sido retirada del origen por quien llama (EconomySim.takeFood). */
    public static boolean launch(ServerLevel level, Village a, Village b, double amount, long now) {
        if (amount <= 0) return false;
        Caravan c = new Caravan(UUID.randomUUID(), a.id, b.id);
        c.cargo = amount;
        c.fromX = a.center.getX();
        c.fromZ = a.center.getZ();
        c.toX = b.center.getX();
        c.toZ = b.center.getZ();
        double dist = Math.hypot(c.toX - c.fromX, c.toZ - c.fromZ);
        c.travel = Math.max(200L, (long) (dist * 1.25D / Caravan.SPEED * 20.0D));
        c.legStart = now;
        c.animalKind = amount >= 120 ? 2 : (amount >= 40 ? 1 : 0);
        CaravanData.get(level).add(c);
        return true;
    }

    /** /alive advance: adelanta las caravanas igual que el resto de la simulacion. */
    public static void shift(ServerLevel level, long ticks) {
        CaravanData cd = CaravanData.get(level);
        for (Caravan c : cd.list()) {
            c.legStart -= ticks;
        }
        cd.setDirty();
    }

    public static int count(ServerLevel level) {
        return CaravanData.get(level).list().size();
    }

    // ------------------------------------------------------------------ tick (1 vez por segundo)

    public static void tick(ServerLevel level) {
        CaravanData cd = CaravanData.get(level);
        if (cd.list().isEmpty()) return;
        VillageData vd = VillageData.get(level);
        long now = level.getGameTime();
        for (Caravan c : cd.list()) {
            try {
                step(level, vd, cd, c, now);
            } catch (RuntimeException ex) {
                com.alive.mod.AliveMod.LOGGER.warn("Alive: error en una caravana: {}", ex.toString());
            }
        }
    }

    private static void step(ServerLevel level, VillageData vd, CaravanData cd, Caravan c, long now) {
        int guard = 0;
        while (guard++ < 3 && cd.get(c.id) != null && now - c.legStart >= c.legTicks()) {
            arrive(level, vd, cd, c, now);
        }
        if (cd.get(c.id) == null) return;

        double f = c.fraction(now);
        Vec3 pos = c.posAt(f, 0);
        BlockPos bp = BlockPos.containing(pos.x, 64, pos.z);
        boolean active = AliveConfig.PHYSICAL_CARAVANS.get() && level.isLoaded(bp) && level.isPositionEntityTicking(bp);
        if (active) {
            c.inactive = 0;
            sustain(level, cd, c, now, f, pos);
        } else if (++c.inactive >= DESPAWN_AFTER) {
            despawn(level, c);
            cd.setDirty();
        }
    }

    private static void arrive(ServerLevel level, VillageData vd, CaravanData cd, Caravan c, long now) {
        Village o = vd.byId(c.origin);
        Village d = vd.byId(c.dest);
        if (!c.returning) {
            if (!c.delivered) {
                // La marca va ANTES de abonar: una mercancia no se puede entregar dos veces
                c.delivered = true;
                double amount = c.cargo;
                c.cargo = 0;
                if (d != null) {
                    EconomySim.deliverFood(d, amount);
                    d.log(now, "Llega una caravana de " + (o != null ? o.name : "una aldea lejana") + " con " + Math.round(amount) + " de comida.");
                    if (o != null) o.log(now, "La caravana entrega " + Math.round(amount) + " de comida en " + d.name + ".");
                } else if (o != null) {
                    EconomySim.deliverFood(o, amount);
                    o.log(now, "El destino ya no existe: la caravana vuelve con la carga.");
                }
                vd.setDirty();
            }
            clearCargoItems(level, c);
            c.returning = true;
            c.legStart += c.legTicks();
            cd.setDirty();
        } else {
            despawn(level, c);
            if (o != null) o.log(now, "La caravana regresa a casa.");
            cd.remove(c.id);
            vd.setDirty();
        }
    }

    // ------------------------------------------------------------------ representacion fisica

    private static void sustain(ServerLevel level, CaravanData cd, Caravan c, long now, double f, Vec3 pos) {
        WanderingTrader tr = trader(level, c);
        if (tr == null) {
            tr = spawnTrader(level, vdName(level, c), c, pos);
            if (tr == null) return;
            cd.setDirty();
        }
        double dist = Math.max(10.0D, Math.hypot(c.endX() - c.startX(), c.endZ() - c.startZ()));
        boolean resting = c.resting(now);

        // Reaccion ante enemigos: el avance se detiene mientras haya hostiles cerca (el mercader huye por su IA)
        if (!level.getEntitiesOfClass(Monster.class, tr.getBoundingBox().inflate(16.0D), Monster::isAlive).isEmpty()) {
            c.legStart += 20L;
            tr.getPersistentData().putBoolean(TAG_WALK, false);
            tr.getNavigation().stop();
            cd.setDirty();
            return;
        }

        // Re-sincronizacion si se ha quedado muy atras (obstaculo): se recoloca en la ruta
        double dx = tr.getX() - pos.x;
        double dz = tr.getZ() - pos.z;
        if (dx * dx + dz * dz > 40.0D * 40.0D) {
            BlockPos g = ground(level, pos.x, pos.z);
            if (g != null) tr.teleportTo(g.getX() + 0.5D, g.getY(), g.getZ() + 0.5D);
        }

        // Camino: se dirige a un punto algo por delante en la ruta; el buscador de rutas esquiva agua, lava y desniveles
        if (resting) {
            tr.getPersistentData().putBoolean(TAG_WALK, true);
            tr.getNavigation().stop();
        } else {
            Vec3 ahead = c.posAt(Math.min(1.0D, f + 10.0D / dist), 0);
            BlockPos g = ground(level, ahead.x, ahead.z);
            if (g != null) {
                tr.getPersistentData().putBoolean(TAG_WALK, true);
                tr.getNavigation().moveTo(g.getX() + 0.5D, g.getY(), g.getZ() + 0.5D, 0.8D);
            }
        }

        // Animal de carga: sigue al mercader
        if (c.animalKind > 0 && !c.animalLost) {
            Mob an = animal(level, c);
            if (an == null) {
                an = spawnAnimal(level, c, tr);
                if (an != null) cd.setDirty();
            }
            if (an != null) {
                double d2 = an.distanceToSqr(tr);
                if (d2 > 32.0D * 32.0D) {
                    an.teleportTo(tr.getX() + 1.5D, tr.getY(), tr.getZ());
                } else if (d2 > 25.0D) {
                    an.getNavigation().moveTo(tr, 1.0D);
                } else if (resting) {
                    an.getNavigation().stop();
                }
            }
        }
    }

    private static String vdName(ServerLevel level, Caravan c) {
        Village o = VillageData.get(level).byId(c.origin);
        return o == null ? "una aldea" : o.name;
    }

    private static WanderingTrader trader(ServerLevel level, Caravan c) {
        if (c.trader == null) return null;
        Entity e = level.getEntity(c.trader);
        return e instanceof WanderingTrader t && t.isAlive() ? t : null;
    }

    private static Mob animal(ServerLevel level, Caravan c) {
        if (c.animal == null) return null;
        Entity e = level.getEntity(c.animal);
        return e instanceof Mob m && m.isAlive() ? m : null;
    }

    private static BlockPos ground(ServerLevel level, double x, double z) {
        BlockPos probe = BlockPos.containing(x, 64, z);
        if (!level.isLoaded(probe)) return null;
        return new BlockPos((int) Math.floor(x), level.getHeight(SURFACE, (int) Math.floor(x), (int) Math.floor(z)), (int) Math.floor(z));
    }

    private static WanderingTrader spawnTrader(ServerLevel level, String originName, Caravan c, Vec3 pos) {
        BlockPos g = ground(level, pos.x, pos.z);
        if (g == null) return null;
        WanderingTrader tr = EntityType.WANDERING_TRADER.spawn(level, g, MobSpawnType.EVENT);
        if (tr == null) return null;
        tr.setDespawnDelay(0);
        tr.setPersistenceRequired();
        tr.setCustomName(Component.literal("Mercader de " + originName));
        tr.setCustomNameVisible(true);
        CompoundTag tag = tr.getPersistentData();
        tag.putString(TAG_ID, c.id.toString());
        tag.putString(TAG_ROLE, "trader");
        tr.goalSelector.addGoal(2, new FollowRouteGoal(tr));
        // Mercancia real: pan en el inventario del mercader (1 pan por cada 4 de comida). Es solo visible: la
        // economia no la lee jamas, asi que no se puede duplicar ni recuperar.
        if (!c.delivered && c.cargo > 0) {
            int items = Math.max(1, (int) Math.round(c.cargo / 4.0D));
            for (int i = 0; i < 8 && items > 0; i++) {
                int n = Math.min(64, items);
                tr.getInventory().addItem(new ItemStack(Items.BREAD, n));
                items -= n;
            }
        }
        c.trader = tr.getUUID();
        return tr;
    }

    private static Mob spawnAnimal(ServerLevel level, Caravan c, WanderingTrader tr) {
        BlockPos at = tr.blockPosition().offset(2, 0, 0);
        EntityType<? extends AbstractChestedHorse> type = c.animalKind >= 2 ? EntityType.MULE : EntityType.DONKEY;
        AbstractChestedHorse an = type.spawn(level, at, MobSpawnType.EVENT);
        if (an == null) return null;
        an.setTamed(true);
        an.setChest(true);
        an.setPersistenceRequired();
        CompoundTag tag = an.getPersistentData();
        tag.putString(TAG_ID, c.id.toString());
        tag.putString(TAG_ROLE, "animal");
        c.animal = an.getUUID();
        return an;
    }

    private static void clearCargoItems(ServerLevel level, Caravan c) {
        WanderingTrader tr = trader(level, c);
        if (tr != null) tr.getInventory().clearContent();
    }

    /** Retira las entidades fisicas (el registro sigue vivo y se vuelve a materializar al regresar a una zona activa). */
    private static void despawn(ServerLevel level, Caravan c) {
        Entity t = c.trader == null ? null : level.getEntity(c.trader);
        if (t != null) t.discard();
        Entity a = c.animal == null ? null : level.getEntity(c.animal);
        if (a != null) a.discard();
        c.trader = null;
        c.animal = null;
    }

    // ------------------------------------------------------------------ eventos

    /**
     * Toda entidad de caravana que "entra" al mundo con la etiqueta ya puesta viene de un chunk guardado: es un
     * fantasma (el registro manda y materializa entidades nuevas). Las nuestras aun no tienen etiqueta al unirse.
     */
    public static boolean isGhost(Entity e) {
        return e.getPersistentData().contains(TAG_ID);
    }

    public static void onDeath(LivingEntity e) {
        if (!(e.level() instanceof ServerLevel level)) return;
        CompoundTag tag = e.getPersistentData();
        if (!tag.contains(TAG_ID)) return;
        UUID id;
        try {
            id = UUID.fromString(tag.getString(TAG_ID));
        } catch (IllegalArgumentException ex) {
            return;
        }
        CaravanData cd = CaravanData.get(level);
        Caravan c = cd.get(id);
        if (c == null) return;
        VillageData vd = VillageData.get(level);
        Village o = vd.byId(c.origin);
        Village d = vd.byId(c.dest);
        long now = level.getGameTime();
        String role = tag.getString(TAG_ROLE);
        if ("trader".equals(role) && e.getUUID().equals(c.trader)) {
            if (o != null) {
                if (!c.delivered) {
                    o.log(now, "La caravana hacia " + (d != null ? d.name : "otra aldea") + " fue atacada: se pierde el cargamento.");
                } else {
                    o.log(now, "El mercader murió en el camino de vuelta.");
                }
            }
            c.cargo = 0;
            c.trader = null;
            despawn(level, c);
            cd.remove(c.id);
            vd.setDirty();
        } else if ("animal".equals(role) && e.getUUID().equals(c.animal)) {
            c.animal = null;
            c.animalLost = true;
            if (!c.delivered) c.cargo *= 0.5D;
            if (o != null) o.log(now, "Una caravana pierde su animal de carga y parte de la mercancía.");
            cd.setDirty();
        }
    }

    /** Meta que mantiene al mercader en ruta: evita que su paseo aleatorio lo desvie. El movimiento lo ordena el gestor. */
    private static final class FollowRouteGoal extends Goal {
        private final PathfinderMob mob;

        FollowRouteGoal(PathfinderMob mob) {
            this.mob = mob;
            setFlags(EnumSet.of(Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            return mob.getPersistentData().getBoolean(TAG_WALK) && mob.getTarget() == null;
        }

        @Override
        public boolean canContinueToUse() {
            return canUse();
        }
    }
}
