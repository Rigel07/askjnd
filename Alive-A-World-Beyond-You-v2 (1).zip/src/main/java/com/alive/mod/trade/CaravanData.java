package com.alive.mod.trade;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Caravanas en ruta de una dimension. Se guarda con el mundo (SavedData). */
public class CaravanData extends SavedData {
    public static final String NAME = "alive_caravans";

    private final Map<UUID, Caravan> caravans = new LinkedHashMap<>();

    public static CaravanData get(ServerLevel level) {
        return level.getDataStorage().computeIfAbsent(CaravanData::load, CaravanData::new, NAME);
    }

    public static CaravanData load(CompoundTag tag) {
        CaravanData d = new CaravanData();
        ListTag l = tag.getList("caravans", Tag.TAG_COMPOUND);
        for (int i = 0; i < l.size(); i++) {
            Caravan c = Caravan.load(l.getCompound(i));
            d.caravans.put(c.id, c);
        }
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag l = new ListTag();
        for (Caravan c : caravans.values()) {
            l.add(c.save());
        }
        tag.put("caravans", l);
        return tag;
    }

    public void add(Caravan c) {
        caravans.put(c.id, c);
        setDirty();
    }

    public void remove(UUID id) {
        caravans.remove(id);
        setDirty();
    }

    public Caravan get(UUID id) {
        return caravans.get(id);
    }

    public List<Caravan> list() {
        return new ArrayList<>(caravans.values());
    }
}
