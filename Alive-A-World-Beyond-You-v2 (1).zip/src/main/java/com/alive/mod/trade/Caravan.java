package com.alive.mod.trade;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.phys.Vec3;

import java.util.UUID;

/**
 * Registro persistente de una caravana. Es la FUENTE DE VERDAD: la posicion se calcula a partir del tiempo de juego,
 * y las entidades fisicas (mercader y animal de carga) son solo su representacion cuando hay jugadores cerca.
 */
public class Caravan {
    public static final long REST_TICKS = 1200L;
    /** Velocidad abstracta de viaje en bloques por segundo. */
    public static final double SPEED = 2.5D;

    public final UUID id;
    public final UUID origin;
    public final UUID dest;
    /** Comida que transporta (0 en el viaje de vuelta o si se ha entregado/perdido). */
    public double cargo;
    /** Una mercancia solo se entrega una vez: esta marca se pone ANTES de abonarla a la economia. */
    public boolean delivered;
    public boolean returning;
    public long legStart;
    public long travel;
    public long rest = REST_TICKS;
    public int fromX, fromZ, toX, toZ;

    public UUID trader;
    public UUID animal;
    public boolean animalLost;
    /** 0 = sin animal, 1 = burro, 2 = mula (segun el tamaño de la carga). */
    public int animalKind;
    /** Segundos seguidos sin jugadores cerca (transitorio). */
    public transient int inactive;

    public Caravan(UUID id, UUID origin, UUID dest) {
        this.id = id;
        this.origin = origin;
        this.dest = dest;
    }

    public long legTicks() {
        return travel + rest;
    }

    /** Fraccion del trayecto actual (0..1); resting=true durante la parada a mitad de camino. */
    public double fraction(long now) {
        long t = Math.max(0L, now - legStart);
        long half = travel / 2;
        if (t < half) return (double) t / Math.max(1L, travel);
        if (t < half + rest) return 0.5D;
        return Math.min(1.0D, (double) (t - rest) / Math.max(1L, travel));
    }

    public boolean resting(long now) {
        long t = now - legStart;
        long half = travel / 2;
        return t >= half && t < half + rest;
    }

    public double startX() {
        return returning ? toX : fromX;
    }

    public double startZ() {
        return returning ? toZ : fromZ;
    }

    public double endX() {
        return returning ? fromX : toX;
    }

    public double endZ() {
        return returning ? fromZ : toZ;
    }

    public Vec3 posAt(double f, double y) {
        return new Vec3(startX() + (endX() - startX()) * f, y, startZ() + (endZ() - startZ()) * f);
    }

    public CompoundTag save() {
        CompoundTag t = new CompoundTag();
        t.putUUID("id", id);
        t.putUUID("origin", origin);
        t.putUUID("dest", dest);
        t.putDouble("cargo", cargo);
        t.putBoolean("delivered", delivered);
        t.putBoolean("returning", returning);
        t.putLong("legStart", legStart);
        t.putLong("travel", travel);
        t.putLong("rest", rest);
        t.putInt("fx", fromX);
        t.putInt("fz", fromZ);
        t.putInt("tx", toX);
        t.putInt("tz", toZ);
        if (trader != null) t.putUUID("trader", trader);
        if (animal != null) t.putUUID("animal", animal);
        t.putBoolean("animalLost", animalLost);
        t.putInt("animalKind", animalKind);
        return t;
    }

    public static Caravan load(CompoundTag t) {
        Caravan c = new Caravan(t.getUUID("id"), t.getUUID("origin"), t.getUUID("dest"));
        c.cargo = t.getDouble("cargo");
        c.delivered = t.getBoolean("delivered");
        c.returning = t.getBoolean("returning");
        c.legStart = t.getLong("legStart");
        c.travel = t.getLong("travel");
        c.rest = t.contains("rest") ? t.getLong("rest") : REST_TICKS;
        c.fromX = t.getInt("fx");
        c.fromZ = t.getInt("fz");
        c.toX = t.getInt("tx");
        c.toZ = t.getInt("tz");
        if (t.hasUUID("trader")) c.trader = t.getUUID("trader");
        if (t.hasUUID("animal")) c.animal = t.getUUID("animal");
        c.animalLost = t.getBoolean("animalLost");
        c.animalKind = t.getInt("animalKind");
        return c;
    }
}
