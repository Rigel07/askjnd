package com.alive.mod.config;

/** Estaciones simuladas opcionales: no cambian el mundo visualmente, solo la produccion y la fauna. */
public final class Seasons {
    public enum Season {
        SPRING("Primavera", 1.0, 1.0),
        SUMMER("Verano", 1.15, 1.1),
        AUTUMN("Otoño", 1.0, 0.9),
        WINTER("Invierno", 0.5, 0.5);

        public final String label;
        public final double crop;
        public final double animal;

        Season(String label, double crop, double animal) {
            this.label = label;
            this.crop = crop;
            this.animal = animal;
        }
    }

    private Seasons() {
    }

    public static Season at(long gameTime) {
        long day = gameTime / 24000L;
        int len = AliveConfig.SEASON_LENGTH_DAYS.get();
        return Season.values()[(int) ((day / len) % 4)];
    }

    public static double crop(long gameTime) {
        return AliveConfig.SEASONS.get() ? at(gameTime).crop : 1.0;
    }

    public static double animal(long gameTime) {
        return AliveConfig.SEASONS.get() ? at(gameTime).animal : 1.0;
    }
}
