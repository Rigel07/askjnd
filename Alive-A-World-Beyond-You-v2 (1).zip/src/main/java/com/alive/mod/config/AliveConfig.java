package com.alive.mod.config;

import net.minecraftforge.common.ForgeConfigSpec;

/** Configuracion del mod (archivo serverconfig/alive-server.toml dentro de cada mundo). */
public final class AliveConfig {
    public static final ForgeConfigSpec SPEC;

    public static final ForgeConfigSpec.BooleanValue VILLAGE_GROWTH;
    public static final ForgeConfigSpec.BooleanValue PERSONALITIES;
    public static final ForgeConfigSpec.BooleanValue SOCIAL;
    public static final ForgeConfigSpec.BooleanValue TRADE;
    public static final ForgeConfigSpec.BooleanValue ANIMALS;
    public static final ForgeConfigSpec.BooleanValue OFFLINE_SIM;
    public static final ForgeConfigSpec.BooleanValue SEASONS;
    public static final ForgeConfigSpec.BooleanValue PROGRESSIVE_BUILD;
    public static final ForgeConfigSpec.BooleanValue PHYSICAL_CARAVANS;
    public static final ForgeConfigSpec.IntValue BUILD_BLOCKS_PER_SECOND;
    public static final ForgeConfigSpec.IntValue SEASON_LENGTH_DAYS;
    public static final ForgeConfigSpec.IntValue SIM_INTERVAL_SECONDS;
    public static final ForgeConfigSpec.IntValue GROWTH_SPEED;
    public static final ForgeConfigSpec.IntValue MAX_POPULATION;
    public static final ForgeConfigSpec.IntValue MAX_EXPANSION;
    public static final ForgeConfigSpec.IntValue EVENT_INTENSITY;
    public static final ForgeConfigSpec.IntValue MAX_ANIMALS_NEARBY;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();

        b.comment("Sistemas que se pueden activar o desactivar individualmente").push("systems");
        VILLAGE_GROWTH = b.comment("Las aldeas crecen: colonos nuevos, construcciones y reparaciones")
                .define("villageGrowth", true);
        PERSONALITIES = b.comment("Los aldeanos tienen personalidad que influye en su comportamiento")
                .define("villagerPersonalities", true);
        SOCIAL = b.comment("Relaciones sociales y amistades entre aldeanos")
                .define("socialRelations", true);
        TRADE = b.comment("Comercio (caravanas abstractas) entre aldeas cercanas")
                .define("villageTrade", true);
        ANIMALS = b.comment("Comportamientos animales avanzados y ecosistema")
                .define("advancedAnimals", true);
        OFFLINE_SIM = b.comment("Simular aldeas y animales fuera de los chunks cargados")
                .define("simulateOutsideLoadedChunks", true);
        SEASONS = b.comment("Estaciones simuladas (afectan a cultivos y animales)")
                .define("seasons", false);
        PROGRESSIVE_BUILD = b.comment("Los edificios se construyen poco a poco con aldeanos constructores (si es false aparecen de golpe)")
                .define("progressiveBuilding", true);
        PHYSICAL_CARAVANS = b.comment("Las caravanas comerciales se ven como mercaderes reales cuando hay jugadores cerca")
                .define("physicalCaravans", true);
        b.pop();

        b.comment("Ajustes de simulacion").push("simulation");
        BUILD_BLOCKS_PER_SECOND = b.comment("Bloques que coloca cada constructor por segundo")
                .defineInRange("buildBlocksPerSecond", 2, 1, 20);
        SIM_INTERVAL_SECONDS = b.comment("Cada cuantos segundos se ejecuta una pasada de simulacion")
                .defineInRange("simulationIntervalSeconds", 20, 5, 600);
        GROWTH_SPEED = b.comment("Velocidad de crecimiento de las aldeas en porcentaje")
                .defineInRange("growthSpeedPercent", 100, 10, 500);
        MAX_POPULATION = b.comment("Poblacion maxima por aldea")
                .defineInRange("maxPopulationPerVillage", 40, 4, 200);
        MAX_EXPANSION = b.comment("Distancia maxima (bloques) desde el centro a la que puede construir una aldea")
                .defineInRange("maxExpansionDistance", 64, 24, 160);
        EVENT_INTENSITY = b.comment("Intensidad de acontecimientos (escasez, emigracion). 0 los desactiva")
                .defineInRange("eventIntensityPercent", 100, 0, 300);
        SEASON_LENGTH_DAYS = b.comment("Duracion de cada estacion en dias de juego")
                .defineInRange("seasonLengthDays", 8, 1, 100);
        MAX_ANIMALS_NEARBY = b.comment("Maximo de animales de la misma especie en 24 bloques antes de impedir nuevas crias")
                .defineInRange("maxAnimalsNearby", 24, 4, 200);
        b.pop();

        SPEC = b.build();
    }

    private AliveConfig() {
    }
}
