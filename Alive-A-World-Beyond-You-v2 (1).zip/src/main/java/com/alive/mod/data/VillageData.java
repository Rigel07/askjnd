package com.alive.mod.data;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Memoria del mundo: todas las aldeas de una dimension. Se guarda con el mundo (SavedData). */
public class VillageData extends SavedData {
    public static final String NAME = "alive_villages";

    private final Map<UUID, Village> villages = new LinkedHashMap<>();

    public static VillageData get(ServerLevel level) {
        return level.getDataStorage().computeIfAbsent(VillageData::load, VillageData::new, NAME);
    }

    public static VillageData load(CompoundTag tag) {
        VillageData d = new VillageData();
        ListTag l = tag.getList("villages", Tag.TAG_COMPOUND);
        for (int i = 0; i < l.size(); i++) {
            Village v = Village.load(l.getCompound(i));
            d.villages.put(v.id, v);
        }
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag l = new ListTag();
        for (Village v : villages.values()) {
            l.add(v.save());
        }
        tag.put("villages", l);
        return tag;
    }

    public void add(Village v) {
        villages.put(v.id, v);
        setDirty();
    }

    public Village byId(UUID id) {
        return villages.get(id);
    }

    public List<Village> list() {
        return new ArrayList<>(villages.values());
    }

    public Village findNearest(BlockPos pos, int maxDist) {
        Village best = null;
        long bestD = (long) maxDist * maxDist;
        for (Village v : villages.values()) {
            long dx = v.center.getX() - pos.getX();
            long dz = v.center.getZ() - pos.getZ();
            long d = dx * dx + dz * dz;
            if (d <= bestD) {
                bestD = d;
                best = v;
            }
        }
        return best;
    }
}
