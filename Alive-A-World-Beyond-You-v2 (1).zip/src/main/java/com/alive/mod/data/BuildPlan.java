package com.alive.mod.data;

import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.nbt.Tag;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayList;
import java.util.List;

/**
 * Plan de obra de un edificio en construccion: lista ordenada de bloques (de abajo hacia arriba).
 * Solo existe mientras el edificio se esta construyendo; se guarda con el mundo para poder reanudar la obra.
 */
public class BuildPlan {
    public final List<BlockPos> pos = new ArrayList<>();
    public final List<BlockState> states = new ArrayList<>();
    /** Pasos ya procesados (colocados u omitidos por proteccion). */
    public int done;
    /** Bloques no vacios del plan al inicio; sirve para repartir el coste en materiales. */
    public int solid;
    /** La obra esta parada por falta de materiales. */
    public boolean stalled;

    public int size() {
        return pos.size();
    }

    public void add(BlockPos p, BlockState st) {
        pos.add(p);
        states.add(st);
        if (!st.isAir()) solid++;
    }

    public CompoundTag save() {
        CompoundTag t = new CompoundTag();
        List<BlockState> palette = new ArrayList<>();
        int[] idx = new int[states.size()];
        long[] ps = new long[pos.size()];
        for (int i = 0; i < states.size(); i++) {
            int k = palette.indexOf(states.get(i));
            if (k < 0) {
                palette.add(states.get(i));
                k = palette.size() - 1;
            }
            idx[i] = k;
            ps[i] = pos.get(i).asLong();
        }
        ListTag pal = new ListTag();
        for (BlockState st : palette) {
            pal.add(NbtUtils.writeBlockState(st));
        }
        t.put("palette", pal);
        t.putIntArray("idx", idx);
        t.putLongArray("pos", ps);
        t.putInt("done", done);
        t.putInt("solid", solid);
        t.putBoolean("stalled", stalled);
        return t;
    }

    public static BuildPlan load(CompoundTag t) {
        BuildPlan plan = new BuildPlan();
        ListTag pal = t.getList("palette", Tag.TAG_COMPOUND);
        List<BlockState> palette = new ArrayList<>();
        for (int i = 0; i < pal.size(); i++) {
            palette.add(NbtUtils.readBlockState(BuiltInRegistries.BLOCK.asLookup(), pal.getCompound(i)));
        }
        int[] idx = t.getIntArray("idx");
        long[] ps = t.getLongArray("pos");
        int n = Math.min(idx.length, ps.length);
        for (int i = 0; i < n; i++) {
            if (idx[i] < 0 || idx[i] >= palette.size()) continue;
            plan.pos.add(BlockPos.of(ps[i]));
            plan.states.add(palette.get(idx[i]));
        }
        plan.done = Math.min(t.getInt("done"), plan.pos.size());
        plan.solid = Math.max(1, t.getInt("solid"));
        plan.stalled = t.getBoolean("stalled");
        return plan;
    }
}
