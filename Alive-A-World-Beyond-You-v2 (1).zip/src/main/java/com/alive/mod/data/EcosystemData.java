package com.alive.mod.data;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.HashMap;
import java.util.Map;

/**
 * Representacion simplificada de la fauna: poblacion estimada por chunk y especie.
 * No hay entidades: solo numeros que se actualizan matematicamente cuando el chunk esta descargado.
 */
public class EcosystemData extends SavedData {
    public static final String NAME = "alive_ecosystem";
    /** Numero de especies seguidas (debe coincidir con animal.Species). */
    public static final int SPECIES = 7;

    public static class Cell {
        public final float[] pop = new float[SPECIES];
        public long lastSim;

        public float total() {
            float s = 0;
            for (float f : pop) s += f;
            return s;
        }
    }

    private final Map<Long, Cell> cells = new HashMap<>();

    public static EcosystemData get(ServerLevel level) {
        return level.getDataStorage().computeIfAbsent(EcosystemData::load, EcosystemData::new, NAME);
    }

    public static EcosystemData load(CompoundTag tag) {
        EcosystemData d = new EcosystemData();
        ListTag l = tag.getList("cells", Tag.TAG_COMPOUND);
        for (int i = 0; i < l.size(); i++) {
            CompoundTag c = l.getCompound(i);
            Cell cell = new Cell();
            cell.lastSim = c.getLong("t");
            int[] p = c.getIntArray("p");
            for (int j = 0; j < Math.min(p.length, SPECIES); j++) {
                cell.pop[j] = p[j] / 100f;
            }
            d.cells.put(c.getLong("k"), cell);
        }
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag l = new ListTag();
        for (Map.Entry<Long, Cell> e : cells.entrySet()) {
            CompoundTag c = new CompoundTag();
            c.putLong("k", e.getKey());
            c.putLong("t", e.getValue().lastSim);
            int[] p = new int[SPECIES];
            for (int j = 0; j < SPECIES; j++) {
                p[j] = Math.round(e.getValue().pop[j] * 100f);
            }
            c.putIntArray("p", p);
            l.add(c);
        }
        tag.put("cells", l);
        return tag;
    }

    public Cell cell(long key, boolean create) {
        Cell c = cells.get(key);
        if (c == null && create) {
            c = new Cell();
            cells.put(key, c);
        }
        return c;
    }

    public Map<Long, Cell> cells() {
        return cells;
    }
}
