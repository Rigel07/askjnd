package com.alive.mod.data;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;

/** Estructura construida por el mod. pos = esquina minima del terreno (5x5) a la altura del suelo. */
public class Building {
    public final BuildingType type;
    public final BlockPos pos;
    public final int style;
    /** Plan de obra mientras se construye; null si el edificio esta terminado. */
    public BuildPlan plan;

    public Building(BuildingType type, BlockPos pos, int style) {
        this.type = type;
        this.pos = pos;
        this.style = style;
    }

    public boolean isComplete() {
        return plan == null;
    }

    public CompoundTag save() {
        CompoundTag t = new CompoundTag();
        t.putInt("t", type.ordinal());
        t.putLong("p", pos.asLong());
        t.putInt("s", style);
        if (plan != null) t.put("plan", plan.save());
        return t;
    }

    public static Building load(CompoundTag t) {
        BuildingType[] types = BuildingType.values();
        BuildingType type = types[Math.floorMod(t.getInt("t"), types.length)];
        Building b = new Building(type, BlockPos.of(t.getLong("p")), t.getInt("s"));
        if (t.contains("plan")) b.plan = BuildPlan.load(t.getCompound("plan"));
        return b;
    }
}
