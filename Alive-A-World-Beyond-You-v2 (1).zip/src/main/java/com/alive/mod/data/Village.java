package com.alive.mod.data;

import com.alive.mod.villager.Role;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.util.RandomSource;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/** Registro persistente de un asentamiento: poblacion, recursos, historia y construcciones. */
public class Village {
    private static final String[] NAME_A = {"Alba", "Brisa", "Cala", "Dorna", "Eldar", "Fresno", "Gala",
            "Hiedra", "Iris", "Junco", "Lomas", "Mirta", "Nogal", "Olmeda", "Pinar", "Roble"};
    private static final String[] NAME_B = {"Verde", "Alta", "del Río", "Nueva", "Vieja", "del Sol", "Clara", "de la Loma"};

    public final UUID id;
    public String name;
    public BlockPos center;
    public long founded;

    public double food = 40;
    public double wood = 20;
    public double stone = 10;
    public double materials = 5;

    public int population;
    public int peakPopulation;
    public int pendingSpawns;
    public int pendingEmigrants;
    public int pendingBuilds;
    public int buildFailures;
    public int baseCapacity;
    public int stage = 1;
    public int scarceSteps;
    public boolean scarce;
    public boolean hasBell;

    public double growthProgress;
    public double buildProgress;
    public double workEthic = 1.0;
    public double cohesion;
    public double generosity;

    public long lastSim;
    public long lastTrade;
    public long noSpaceUntil;

    public final int[] roles = new int[Role.values().length];
    public final List<Building> buildings = new ArrayList<>();
    public final Set<UUID> routes = new HashSet<>();
    public final List<String> history = new ArrayList<>();

    public Village(UUID id, String name, BlockPos center, long now) {
        this.id = id;
        this.name = name;
        this.center = center;
        this.founded = now;
        this.lastSim = now;
        this.lastTrade = now;
    }

    public static String randomName(RandomSource r) {
        return NAME_A[r.nextInt(NAME_A.length)] + " " + NAME_B[r.nextInt(NAME_B.length)];
    }

    public int count(BuildingType t) {
        int n = 0;
        for (Building b : buildings) {
            if (b.type == t) n++;
        }
        return n;
    }

    /** Edificios terminados de un tipo (los que siguen en obra no cuentan). */
    public int countBuilt(BuildingType t) {
        int n = 0;
        for (Building b : buildings) {
            if (b.type == t && b.isComplete()) n++;
        }
        return n;
    }

    /** Edificio en construccion, o null. */
    public Building underConstruction() {
        for (Building b : buildings) {
            if (b.plan != null) return b;
        }
        return null;
    }

    public int role(Role r) {
        return roles[r.ordinal()];
    }

    public void log(long time, String msg) {
        history.add("[Día " + (time / 24000L) + "] " + msg);
        while (history.size() > 40) {
            history.remove(0);
        }
    }

    public CompoundTag save() {
        CompoundTag t = new CompoundTag();
        t.putUUID("id", id);
        t.putString("name", name);
        t.putLong("center", center.asLong());
        t.putLong("founded", founded);
        t.putDouble("food", food);
        t.putDouble("wood", wood);
        t.putDouble("stone", stone);
        t.putDouble("materials", materials);
        t.putInt("pop", population);
        t.putInt("peak", peakPopulation);
        t.putInt("pSpawns", pendingSpawns);
        t.putInt("pEmi", pendingEmigrants);
        t.putInt("pBuilds", pendingBuilds);
        t.putInt("bFails", buildFailures);
        t.putInt("baseCap", baseCapacity);
        t.putInt("stage", stage);
        t.putInt("scarceSteps", scarceSteps);
        t.putBoolean("scarce", scarce);
        t.putBoolean("bell", hasBell);
        t.putDouble("growth", growthProgress);
        t.putDouble("buildProg", buildProgress);
        t.putDouble("ethic", workEthic);
        t.putDouble("cohesion", cohesion);
        t.putDouble("generosity", generosity);
        t.putLong("lastSim", lastSim);
        t.putLong("lastTrade", lastTrade);
        t.putLong("noSpace", noSpaceUntil);
        t.putIntArray("roles", roles);
        ListTag bl = new ListTag();
        for (Building b : buildings) {
            bl.add(b.save());
        }
        t.put("buildings", bl);
        ListTag rl = new ListTag();
        for (UUID u : routes) {
            rl.add(StringTag.valueOf(u.toString()));
        }
        t.put("routes", rl);
        ListTag hl = new ListTag();
        for (String s : history) {
            hl.add(StringTag.valueOf(s));
        }
        t.put("history", hl);
        return t;
    }

    public static Village load(CompoundTag t) {
        Village v = new Village(t.getUUID("id"), t.getString("name"), BlockPos.of(t.getLong("center")), t.getLong("founded"));
        v.food = t.getDouble("food");
        v.wood = t.getDouble("wood");
        v.stone = t.getDouble("stone");
        v.materials = t.getDouble("materials");
        v.population = t.getInt("pop");
        v.peakPopulation = t.getInt("peak");
        v.pendingSpawns = t.getInt("pSpawns");
        v.pendingEmigrants = t.getInt("pEmi");
        v.pendingBuilds = t.getInt("pBuilds");
        v.buildFailures = t.getInt("bFails");
        v.baseCapacity = t.getInt("baseCap");
        v.stage = Math.max(1, t.getInt("stage"));
        v.scarceSteps = t.getInt("scarceSteps");
        v.scarce = t.getBoolean("scarce");
        v.hasBell = t.getBoolean("bell");
        v.growthProgress = t.getDouble("growth");
        v.buildProgress = t.getDouble("buildProg");
        v.workEthic = t.contains("ethic") ? t.getDouble("ethic") : 1.0;
        v.cohesion = t.getDouble("cohesion");
        v.generosity = t.getDouble("generosity");
        v.lastSim = t.getLong("lastSim");
        v.lastTrade = t.getLong("lastTrade");
        v.noSpaceUntil = t.getLong("noSpace");
        int[] r = t.getIntArray("roles");
        System.arraycopy(r, 0, v.roles, 0, Math.min(r.length, v.roles.length));
        ListTag bl = t.getList("buildings", Tag.TAG_COMPOUND);
        for (int i = 0; i < bl.size(); i++) {
            v.buildings.add(Building.load(bl.getCompound(i)));
        }
        ListTag rl = t.getList("routes", Tag.TAG_STRING);
        for (int i = 0; i < rl.size(); i++) {
            try {
                v.routes.add(UUID.fromString(rl.getString(i)));
            } catch (IllegalArgumentException ignored) {
                // dato corrupto: se ignora
            }
        }
        ListTag hl = t.getList("history", Tag.TAG_STRING);
        for (int i = 0; i < hl.size(); i++) {
            v.history.add(hl.getString(i));
        }
        return v;
    }
}
