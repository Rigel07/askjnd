package com.alive.mod.data;

public enum BuildingType {
    HOUSE("vivienda"),
    FARM("granja"),
    STORAGE("almacén"),
    PLAZA("plaza");

    public final String label;

    BuildingType(String label) {
        this.label = label;
    }
}
